import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { useTranslation } from "react-i18next";
import { Upload, File, X, CheckCircle, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface FileUploaderProps {
  onFileSelect: (file: File) => void;
  selectedFile: File | null;
  onClear: () => void;
  isConverting?: boolean;
  conversionProgress?: number;
  conversionStatus?: "idle" | "uploading" | "converting" | "completed" | "error";
  disabled?: boolean;
}

export function FileUploader({
  onFileSelect,
  selectedFile,
  onClear,
  isConverting = false,
  conversionProgress = 0,
  conversionStatus = "idle",
  disabled = false,
}: FileUploaderProps) {
  const { t } = useTranslation();
  const [isDragActive, setIsDragActive] = useState(false);

  const onDrop = useCallback(
    (acceptedFiles: File[]) => {
      if (acceptedFiles.length > 0 && !disabled) {
        onFileSelect(acceptedFiles[0]);
      }
    },
    [onFileSelect, disabled]
  );

  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
    multiple: false,
    disabled: disabled || isConverting,
    onDragEnter: () => setIsDragActive(true),
    onDragLeave: () => setIsDragActive(false),
    accept: {
      "application/pdf": [".pdf"],
      "application/msword": [".doc"],
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
      "application/vnd.ms-excel": [".xls"],
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [".xlsx"],
      "application/vnd.ms-powerpoint": [".ppt"],
      "application/vnd.openxmlformats-officedocument.presentationml.presentation": [".pptx"],
      "text/plain": [".txt"],
      "text/html": [".html", ".htm"],
      "text/csv": [".csv"],
      "application/rtf": [".rtf"],
      "application/vnd.oasis.opendocument.text": [".odt"],
      "application/vnd.oasis.opendocument.spreadsheet": [".ods"],
      "image/png": [".png"],
      "image/jpeg": [".jpg", ".jpeg"],
      "image/gif": [".gif"],
      "image/webp": [".webp"],
      "image/tiff": [".tiff", ".tif"],
      "image/bmp": [".bmp"],
      "application/epub+zip": [".epub"],
    },
  });

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const getFileExtension = (filename: string) => {
    return filename.split(".").pop()?.toUpperCase() || "FILE";
  };

  if (selectedFile) {
    return (
      <Card className="p-6 border-2">
        <div className="flex items-start gap-4">
          <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
            <File className="h-6 w-6 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2 mb-1">
              <p className="font-medium truncate" data-testid="text-file-name">
                {selectedFile.name}
              </p>
              {!isConverting && conversionStatus === "idle" && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onClear}
                  data-testid="button-clear-file"
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span className="px-2 py-0.5 bg-muted rounded text-xs font-medium">
                {getFileExtension(selectedFile.name)}
              </span>
              <span>{formatFileSize(selectedFile.size)}</span>
            </div>

            {(isConverting || conversionStatus !== "idle") && (
              <div className="mt-4 space-y-2">
                <Progress value={conversionProgress} className="h-2" />
                <div className="flex items-center gap-2 text-sm">
                  {conversionStatus === "uploading" && (
                    <>
                      <div className="h-2 w-2 bg-blue-500 rounded-full animate-pulse" />
                      <span>Uploading... {conversionProgress}%</span>
                    </>
                  )}
                  {conversionStatus === "converting" && (
                    <>
                      <div className="h-2 w-2 bg-yellow-500 rounded-full animate-pulse" />
                      <span>{t("converter.converting")} {conversionProgress}%</span>
                    </>
                  )}
                  {conversionStatus === "completed" && (
                    <>
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-green-600">{t("converter.success")}</span>
                    </>
                  )}
                  {conversionStatus === "error" && (
                    <>
                      <AlertCircle className="h-4 w-4 text-destructive" />
                      <span className="text-destructive">{t("converter.error")}</span>
                    </>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </Card>
    );
  }

  return (
    <div
      {...getRootProps()}
      className={cn(
        "border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-all duration-200",
        isDragActive
          ? "border-primary bg-primary/5"
          : "border-muted-foreground/25 hover:border-primary/50 hover:bg-muted/50",
        disabled && "opacity-50 cursor-not-allowed"
      )}
      data-testid="dropzone-file-upload"
    >
      <input {...getInputProps()} data-testid="input-file-upload" />
      <div className="flex flex-col items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center">
          <Upload className={cn(
            "h-8 w-8 transition-colors",
            isDragActive ? "text-primary" : "text-muted-foreground"
          )} />
        </div>
        <div>
          <p className="text-lg font-medium mb-1">
            {t("converter.dragDrop")}
          </p>
          <p className="text-muted-foreground mb-4">{t("converter.or")}</p>
          <Button type="button" variant="outline" disabled={disabled} data-testid="button-browse-files">
            {t("converter.browse")}
          </Button>
        </div>
        <div className="text-sm text-muted-foreground space-y-1">
          <p>{t("converter.supportedFormats")}</p>
          <p>{t("converter.maxSize")}</p>
        </div>
      </div>
    </div>
  );
}
