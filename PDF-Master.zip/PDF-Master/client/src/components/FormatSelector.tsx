import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Search, FileText, Table, Image, BookOpen, Presentation, Database, ArrowRight } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { conversionFormats } from "@shared/schema";

interface FormatSelectorProps {
  inputFormat: string | null;
  selectedFormat: string | null;
  onFormatSelect: (format: { from: string; to: string; label: string }) => void;
}

type CategoryKey = "all" | "documents" | "spreadsheets" | "images" | "ebooks" | "presentations" | "data";

const categoryIcons: Record<string, React.ReactNode> = {
  documents: <FileText className="h-4 w-4" />,
  spreadsheets: <Table className="h-4 w-4" />,
  images: <Image className="h-4 w-4" />,
  ebooks: <BookOpen className="h-4 w-4" />,
  presentations: <Presentation className="h-4 w-4" />,
  data: <Database className="h-4 w-4" />,
};

export function FormatSelector({ inputFormat, selectedFormat, onFormatSelect }: FormatSelectorProps) {
  const { t } = useTranslation();
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState<CategoryKey>("all");

  const categories: CategoryKey[] = ["all", "documents", "spreadsheets", "images", "ebooks", "presentations", "data"];

  const getAllFormats = () => {
    const allFormats: { from: string; to: string; label: string; category: string }[] = [];
    
    Object.entries(conversionFormats).forEach(([category, formats]) => {
      formats.forEach((format) => {
        allFormats.push({ ...format, category });
      });
    });
    
    return allFormats;
  };

  const getFilteredFormats = () => {
    let formats = getAllFormats();

    if (inputFormat) {
      formats = formats.filter((f) => f.from.toLowerCase() === inputFormat.toLowerCase());
    }

    if (activeCategory !== "all") {
      formats = formats.filter((f) => f.category === activeCategory);
    }

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      formats = formats.filter(
        (f) =>
          f.from.toLowerCase().includes(query) ||
          f.to.toLowerCase().includes(query) ||
          f.label.toLowerCase().includes(query)
      );
    }

    return formats;
  };

  const filteredFormats = getFilteredFormats();

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder={t("common.search")}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
          data-testid="input-format-search"
        />
      </div>

      <div className="flex flex-wrap gap-2">
        {categories.map((category) => (
          <Badge
            key={category}
            variant={activeCategory === category ? "default" : "secondary"}
            className="cursor-pointer gap-1.5"
            onClick={() => setActiveCategory(category)}
            data-testid={`badge-category-${category}`}
          >
            {category !== "all" && categoryIcons[category]}
            {t(`converter.categories.${category}`)}
          </Badge>
        ))}
      </div>

      <ScrollArea className="h-[280px]">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {filteredFormats.map((format, index) => (
            <button
              key={`${format.from}-${format.to}-${index}`}
              onClick={() => onFormatSelect(format)}
              className={cn(
                "flex items-center gap-3 p-3 rounded-lg border text-left transition-all hover-elevate",
                selectedFormat === format.to && inputFormat === format.from
                  ? "border-primary bg-primary/5"
                  : "border-transparent bg-muted/50"
              )}
              data-testid={`button-format-${format.from}-${format.to}`}
            >
              <div className="flex items-center gap-2 flex-1 min-w-0">
                <span className="px-2 py-0.5 bg-background rounded text-xs font-medium uppercase">
                  {format.from}
                </span>
                <ArrowRight className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                <span className="px-2 py-0.5 bg-primary/10 text-primary rounded text-xs font-medium uppercase">
                  {format.to}
                </span>
              </div>
            </button>
          ))}
        </div>

        {filteredFormats.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
            <Search className="h-8 w-8 mb-2 opacity-50" />
            <p>{t("common.noResults")}</p>
          </div>
        )}
      </ScrollArea>
    </div>
  );
}
