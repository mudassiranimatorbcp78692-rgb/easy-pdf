import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

const resources = {
  en: {
    translation: {
      // Navigation
      nav: {
        home: "Home",
        convert: "Convert",
        history: "History",
        settings: "Settings",
        logout: "Logout",
        login: "Login",
        getStarted: "Get Started"
      },
      // Landing Page
      landing: {
        title: "Convert PDF to Any Format",
        subtitle: "Fast, secure, and free PDF conversion to 50+ formats. No registration required for basic conversions.",
        cta: "Start Converting Now",
        trustedBy: "Trusted by 10,000+ users worldwide",
        features: {
          fast: "Lightning Fast",
          fastDesc: "Convert files in seconds with our optimized processing engine",
          secure: "100% Secure",
          secureDesc: "Your files are encrypted and automatically deleted after conversion",
          free: "Free Forever",
          freeDesc: "No hidden costs or subscriptions. All basic features are free",
          formats: "50+ Formats",
          formatsDesc: "Support for documents, images, spreadsheets, and more"
        },
        categories: {
          documents: "Documents",
          documentsDesc: "PDF, DOCX, DOC, TXT, RTF, ODT, HTML, Markdown",
          spreadsheets: "Spreadsheets",
          spreadsheetsDesc: "XLSX, XLS, CSV, ODS, XML, JSON",
          images: "Images",
          imagesDesc: "PNG, JPG, GIF, TIFF, BMP, WEBP, SVG",
          ebooks: "E-Books",
          ebooksDesc: "EPUB, MOBI, AZW3, FB2",
          presentations: "Presentations",
          presentationsDesc: "PPTX, PPT, ODP",
          data: "Data Files",
          dataDesc: "XML, JSON, YAML, CSV"
        },
        howItWorks: {
          title: "How It Works",
          step1: "Upload Your File",
          step1Desc: "Drag and drop or click to upload your PDF or document",
          step2: "Choose Format",
          step2Desc: "Select your desired output format from 50+ options",
          step3: "Download",
          step3Desc: "Get your converted file instantly"
        }
      },
      // Dashboard
      dashboard: {
        welcome: "Welcome back",
        recentConversions: "Recent Conversions",
        totalConversions: "Total Conversions",
        storageUsed: "Storage Used",
        quickConvert: "Quick Convert",
        viewAll: "View All",
        noConversions: "No conversions yet",
        startConverting: "Start your first conversion"
      },
      // Converter
      converter: {
        title: "Convert Your Files",
        dragDrop: "Drag and drop your file here",
        or: "or",
        browse: "Browse Files",
        supportedFormats: "Supported formats: PDF, DOCX, XLSX, PNG, JPG and more",
        maxSize: "Maximum file size: 50MB",
        selectFormat: "Select Output Format",
        convert: "Convert Now",
        converting: "Converting...",
        downloadReady: "Download Ready",
        download: "Download File",
        convertAnother: "Convert Another File",
        error: "Conversion failed. Please try again.",
        success: "File converted successfully!",
        categories: {
          all: "All Formats",
          documents: "Documents",
          spreadsheets: "Spreadsheets",
          images: "Images",
          ebooks: "E-Books",
          presentations: "Presentations",
          data: "Data"
        }
      },
      // History
      history: {
        title: "Conversion History",
        fileName: "File Name",
        originalFormat: "Original",
        targetFormat: "Target",
        date: "Date",
        status: "Status",
        actions: "Actions",
        download: "Download",
        delete: "Delete",
        noHistory: "No conversion history",
        pending: "Pending",
        processing: "Processing",
        completed: "Completed",
        failed: "Failed"
      },
      // Settings
      settings: {
        title: "Settings",
        language: "Language",
        theme: "Theme",
        themeLight: "Light",
        themeDark: "Dark",
        themeSystem: "System",
        notifications: "Notifications",
        notificationsDesc: "Receive email notifications about your conversions",
        save: "Save Changes",
        saved: "Settings saved successfully"
      },
      // Common
      common: {
        loading: "Loading...",
        error: "Error",
        success: "Success",
        cancel: "Cancel",
        confirm: "Confirm",
        delete: "Delete",
        save: "Save",
        back: "Back",
        next: "Next",
        close: "Close",
        search: "Search",
        filter: "Filter",
        noResults: "No results found"
      },
      // Footer
      footer: {
        copyright: "All rights reserved",
        privacy: "Privacy Policy",
        terms: "Terms of Service",
        contact: "Contact Us"
      }
    }
  },
  ur: {
    translation: {
      nav: {
        home: "ہوم",
        convert: "کنورٹ کریں",
        history: "ہسٹری",
        settings: "سیٹنگز",
        logout: "لاگ آؤٹ",
        login: "لاگ ان",
        getStarted: "شروع کریں"
      },
      landing: {
        title: "PDF کو کسی بھی فارمیٹ میں تبدیل کریں",
        subtitle: "50+ فارمیٹس میں تیز، محفوظ، اور مفت PDF تبدیلی۔ بنیادی تبدیلیوں کے لیے رجسٹریشن کی ضرورت نہیں۔",
        cta: "ابھی کنورٹ کرنا شروع کریں",
        trustedBy: "دنیا بھر میں 10,000+ صارفین کا اعتماد",
        features: {
          fast: "بجلی کی رفتار",
          fastDesc: "ہمارے بہتر پروسیسنگ انجن کے ساتھ سیکنڈوں میں فائلیں تبدیل کریں",
          secure: "100% محفوظ",
          secureDesc: "آپ کی فائلیں انکرپٹڈ ہیں اور تبدیلی کے بعد خودکار طور پر حذف ہو جاتی ہیں",
          free: "ہمیشہ مفت",
          freeDesc: "کوئی پوشیدہ لاگت یا سبسکرپشن نہیں۔ تمام بنیادی خصوصیات مفت ہیں",
          formats: "50+ فارمیٹس",
          formatsDesc: "دستاویزات، تصاویر، اسپریڈشیٹس، اور مزید کے لیے سپورٹ"
        },
        categories: {
          documents: "دستاویزات",
          documentsDesc: "PDF, DOCX, DOC, TXT, RTF, ODT, HTML, Markdown",
          spreadsheets: "اسپریڈشیٹس",
          spreadsheetsDesc: "XLSX, XLS, CSV, ODS, XML, JSON",
          images: "تصاویر",
          imagesDesc: "PNG, JPG, GIF, TIFF, BMP, WEBP, SVG",
          ebooks: "ای-بکس",
          ebooksDesc: "EPUB, MOBI, AZW3, FB2",
          presentations: "پریزنٹیشنز",
          presentationsDesc: "PPTX, PPT, ODP",
          data: "ڈیٹا فائلز",
          dataDesc: "XML, JSON, YAML, CSV"
        },
        howItWorks: {
          title: "یہ کیسے کام کرتا ہے",
          step1: "اپنی فائل اپلوڈ کریں",
          step1Desc: "اپنی PDF یا دستاویز اپلوڈ کرنے کے لیے ڈریگ اینڈ ڈراپ کریں یا کلک کریں",
          step2: "فارمیٹ منتخب کریں",
          step2Desc: "50+ آپشنز میں سے اپنا مطلوبہ آؤٹ پٹ فارمیٹ منتخب کریں",
          step3: "ڈاؤن لوڈ کریں",
          step3Desc: "اپنی تبدیل شدہ فائل فوری طور پر حاصل کریں"
        }
      },
      dashboard: {
        welcome: "خوش آمدید",
        recentConversions: "حالیہ تبدیلیاں",
        totalConversions: "کل تبدیلیاں",
        storageUsed: "استعمال شدہ اسٹوریج",
        quickConvert: "فوری تبدیلی",
        viewAll: "سب دیکھیں",
        noConversions: "ابھی تک کوئی تبدیلی نہیں",
        startConverting: "اپنی پہلی تبدیلی شروع کریں"
      },
      converter: {
        title: "اپنی فائلیں تبدیل کریں",
        dragDrop: "اپنی فائل یہاں ڈریگ اور ڈراپ کریں",
        or: "یا",
        browse: "فائلیں براؤز کریں",
        supportedFormats: "سپورٹڈ فارمیٹس: PDF, DOCX, XLSX, PNG, JPG اور مزید",
        maxSize: "زیادہ سے زیادہ فائل سائز: 50MB",
        selectFormat: "آؤٹ پٹ فارمیٹ منتخب کریں",
        convert: "ابھی تبدیل کریں",
        converting: "تبدیل ہو رہا ہے...",
        downloadReady: "ڈاؤن لوڈ تیار ہے",
        download: "فائل ڈاؤن لوڈ کریں",
        convertAnother: "ایک اور فائل تبدیل کریں",
        error: "تبدیلی ناکام ہوگئی۔ براہ کرم دوبارہ کوشش کریں۔",
        success: "فائل کامیابی سے تبدیل ہوگئی!",
        categories: {
          all: "تمام فارمیٹس",
          documents: "دستاویزات",
          spreadsheets: "اسپریڈشیٹس",
          images: "تصاویر",
          ebooks: "ای-بکس",
          presentations: "پریزنٹیشنز",
          data: "ڈیٹا"
        }
      },
      history: {
        title: "تبدیلی کی ہسٹری",
        fileName: "فائل کا نام",
        originalFormat: "اصل",
        targetFormat: "ٹارگٹ",
        date: "تاریخ",
        status: "حیثیت",
        actions: "ایکشنز",
        download: "ڈاؤن لوڈ",
        delete: "حذف کریں",
        noHistory: "کوئی تبدیلی کی ہسٹری نہیں",
        pending: "زیر التواء",
        processing: "پراسیسنگ",
        completed: "مکمل",
        failed: "ناکام"
      },
      settings: {
        title: "سیٹنگز",
        language: "زبان",
        theme: "تھیم",
        themeLight: "لائٹ",
        themeDark: "ڈارک",
        themeSystem: "سسٹم",
        notifications: "نوٹیفیکیشنز",
        notificationsDesc: "اپنی تبدیلیوں کے بارے میں ای میل نوٹیفیکیشنز حاصل کریں",
        save: "تبدیلیاں محفوظ کریں",
        saved: "سیٹنگز کامیابی سے محفوظ ہوگئیں"
      },
      common: {
        loading: "لوڈ ہو رہا ہے...",
        error: "خرابی",
        success: "کامیابی",
        cancel: "منسوخ",
        confirm: "تصدیق",
        delete: "حذف کریں",
        save: "محفوظ کریں",
        back: "واپس",
        next: "اگلا",
        close: "بند کریں",
        search: "تلاش",
        filter: "فلٹر",
        noResults: "کوئی نتیجہ نہیں ملا"
      },
      footer: {
        copyright: "جملہ حقوق محفوظ ہیں",
        privacy: "پرائیویسی پالیسی",
        terms: "سروس کی شرائط",
        contact: "ہم سے رابطہ کریں"
      }
    }
  },
  ar: {
    translation: {
      nav: {
        home: "الرئيسية",
        convert: "تحويل",
        history: "السجل",
        settings: "الإعدادات",
        logout: "تسجيل الخروج",
        login: "تسجيل الدخول",
        getStarted: "ابدأ الآن"
      },
      landing: {
        title: "حوّل PDF إلى أي صيغة",
        subtitle: "تحويل PDF سريع وآمن ومجاني إلى أكثر من 50 صيغة. لا حاجة للتسجيل للتحويلات الأساسية.",
        cta: "ابدأ التحويل الآن",
        trustedBy: "موثوق من قبل أكثر من 10,000 مستخدم حول العالم",
        features: {
          fast: "سرعة البرق",
          fastDesc: "حوّل الملفات في ثوانٍ مع محرك المعالجة المحسّن لدينا",
          secure: "آمن 100%",
          secureDesc: "ملفاتك مشفرة وتُحذف تلقائياً بعد التحويل",
          free: "مجاني للأبد",
          freeDesc: "لا تكاليف خفية أو اشتراكات. جميع الميزات الأساسية مجانية",
          formats: "أكثر من 50 صيغة",
          formatsDesc: "دعم للمستندات والصور وجداول البيانات والمزيد"
        },
        categories: {
          documents: "المستندات",
          documentsDesc: "PDF, DOCX, DOC, TXT, RTF, ODT, HTML, Markdown",
          spreadsheets: "جداول البيانات",
          spreadsheetsDesc: "XLSX, XLS, CSV, ODS, XML, JSON",
          images: "الصور",
          imagesDesc: "PNG, JPG, GIF, TIFF, BMP, WEBP, SVG",
          ebooks: "الكتب الإلكترونية",
          ebooksDesc: "EPUB, MOBI, AZW3, FB2",
          presentations: "العروض التقديمية",
          presentationsDesc: "PPTX, PPT, ODP",
          data: "ملفات البيانات",
          dataDesc: "XML, JSON, YAML, CSV"
        },
        howItWorks: {
          title: "كيف يعمل",
          step1: "ارفع ملفك",
          step1Desc: "اسحب وأفلت أو انقر لرفع ملف PDF أو المستند الخاص بك",
          step2: "اختر الصيغة",
          step2Desc: "اختر صيغة الإخراج المطلوبة من أكثر من 50 خياراً",
          step3: "حمّل",
          step3Desc: "احصل على ملفك المحوّل فوراً"
        }
      },
      dashboard: {
        welcome: "مرحباً بعودتك",
        recentConversions: "التحويلات الأخيرة",
        totalConversions: "إجمالي التحويلات",
        storageUsed: "التخزين المستخدم",
        quickConvert: "تحويل سريع",
        viewAll: "عرض الكل",
        noConversions: "لا توجد تحويلات بعد",
        startConverting: "ابدأ تحويلك الأول"
      },
      converter: {
        title: "حوّل ملفاتك",
        dragDrop: "اسحب وأفلت ملفك هنا",
        or: "أو",
        browse: "تصفح الملفات",
        supportedFormats: "الصيغ المدعومة: PDF, DOCX, XLSX, PNG, JPG والمزيد",
        maxSize: "الحد الأقصى لحجم الملف: 50 ميجابايت",
        selectFormat: "اختر صيغة الإخراج",
        convert: "حوّل الآن",
        converting: "جارٍ التحويل...",
        downloadReady: "التحميل جاهز",
        download: "حمّل الملف",
        convertAnother: "حوّل ملفاً آخر",
        error: "فشل التحويل. يرجى المحاولة مرة أخرى.",
        success: "تم تحويل الملف بنجاح!",
        categories: {
          all: "جميع الصيغ",
          documents: "المستندات",
          spreadsheets: "جداول البيانات",
          images: "الصور",
          ebooks: "الكتب الإلكترونية",
          presentations: "العروض",
          data: "البيانات"
        }
      },
      history: {
        title: "سجل التحويل",
        fileName: "اسم الملف",
        originalFormat: "الأصلي",
        targetFormat: "الهدف",
        date: "التاريخ",
        status: "الحالة",
        actions: "الإجراءات",
        download: "تحميل",
        delete: "حذف",
        noHistory: "لا يوجد سجل تحويل",
        pending: "قيد الانتظار",
        processing: "قيد المعالجة",
        completed: "مكتمل",
        failed: "فشل"
      },
      settings: {
        title: "الإعدادات",
        language: "اللغة",
        theme: "المظهر",
        themeLight: "فاتح",
        themeDark: "داكن",
        themeSystem: "النظام",
        notifications: "الإشعارات",
        notificationsDesc: "تلقي إشعارات البريد الإلكتروني حول تحويلاتك",
        save: "حفظ التغييرات",
        saved: "تم حفظ الإعدادات بنجاح"
      },
      common: {
        loading: "جارٍ التحميل...",
        error: "خطأ",
        success: "نجاح",
        cancel: "إلغاء",
        confirm: "تأكيد",
        delete: "حذف",
        save: "حفظ",
        back: "رجوع",
        next: "التالي",
        close: "إغلاق",
        search: "بحث",
        filter: "تصفية",
        noResults: "لم يتم العثور على نتائج"
      },
      footer: {
        copyright: "جميع الحقوق محفوظة",
        privacy: "سياسة الخصوصية",
        terms: "شروط الخدمة",
        contact: "اتصل بنا"
      }
    }
  },
  hi: {
    translation: {
      nav: {
        home: "होम",
        convert: "कन्वर्ट करें",
        history: "इतिहास",
        settings: "सेटिंग्स",
        logout: "लॉग आउट",
        login: "लॉग इन",
        getStarted: "शुरू करें"
      },
      landing: {
        title: "PDF को किसी भी फॉर्मेट में बदलें",
        subtitle: "50+ फॉर्मेट में तेज़, सुरक्षित और मुफ्त PDF रूपांतरण। बुनियादी रूपांतरण के लिए पंजीकरण आवश्यक नहीं।",
        cta: "अभी कन्वर्ट करना शुरू करें",
        trustedBy: "दुनिया भर में 10,000+ उपयोगकर्ताओं द्वारा विश्वसनीय",
        features: {
          fast: "बिजली की गति",
          fastDesc: "हमारे अनुकूलित प्रोसेसिंग इंजन के साथ सेकंड में फ़ाइलें बदलें",
          secure: "100% सुरक्षित",
          secureDesc: "आपकी फ़ाइलें एन्क्रिप्टेड हैं और रूपांतरण के बाद स्वचालित रूप से हटा दी जाती हैं",
          free: "हमेशा मुफ्त",
          freeDesc: "कोई छिपी लागत या सब्सक्रिप्शन नहीं। सभी बुनियादी सुविधाएं मुफ्त हैं",
          formats: "50+ फॉर्मेट",
          formatsDesc: "दस्तावेज़, छवियां, स्प्रेडशीट और अधिक के लिए समर्थन"
        },
        categories: {
          documents: "दस्तावेज़",
          documentsDesc: "PDF, DOCX, DOC, TXT, RTF, ODT, HTML, Markdown",
          spreadsheets: "स्प्रेडशीट",
          spreadsheetsDesc: "XLSX, XLS, CSV, ODS, XML, JSON",
          images: "छवियां",
          imagesDesc: "PNG, JPG, GIF, TIFF, BMP, WEBP, SVG",
          ebooks: "ई-बुक्स",
          ebooksDesc: "EPUB, MOBI, AZW3, FB2",
          presentations: "प्रस्तुतियां",
          presentationsDesc: "PPTX, PPT, ODP",
          data: "डेटा फ़ाइलें",
          dataDesc: "XML, JSON, YAML, CSV"
        },
        howItWorks: {
          title: "यह कैसे काम करता है",
          step1: "अपनी फ़ाइल अपलोड करें",
          step1Desc: "अपनी PDF या दस्तावेज़ अपलोड करने के लिए ड्रैग और ड्रॉप करें या क्लिक करें",
          step2: "फॉर्मेट चुनें",
          step2Desc: "50+ विकल्पों में से अपना वांछित आउटपुट फॉर्मेट चुनें",
          step3: "डाउनलोड करें",
          step3Desc: "अपनी रूपांतरित फ़ाइल तुरंत प्राप्त करें"
        }
      },
      dashboard: {
        welcome: "वापसी पर स्वागत है",
        recentConversions: "हाल के रूपांतरण",
        totalConversions: "कुल रूपांतरण",
        storageUsed: "उपयोग किया गया स्टोरेज",
        quickConvert: "त्वरित रूपांतरण",
        viewAll: "सभी देखें",
        noConversions: "अभी तक कोई रूपांतरण नहीं",
        startConverting: "अपना पहला रूपांतरण शुरू करें"
      },
      converter: {
        title: "अपनी फ़ाइलें कन्वर्ट करें",
        dragDrop: "अपनी फ़ाइल यहां ड्रैग और ड्रॉप करें",
        or: "या",
        browse: "फ़ाइलें ब्राउज़ करें",
        supportedFormats: "समर्थित फॉर्मेट: PDF, DOCX, XLSX, PNG, JPG और अधिक",
        maxSize: "अधिकतम फ़ाइल आकार: 50MB",
        selectFormat: "आउटपुट फॉर्मेट चुनें",
        convert: "अभी कन्वर्ट करें",
        converting: "कन्वर्ट हो रहा है...",
        downloadReady: "डाउनलोड तैयार",
        download: "फ़ाइल डाउनलोड करें",
        convertAnother: "एक और फ़ाइल कन्वर्ट करें",
        error: "रूपांतरण विफल। कृपया पुनः प्रयास करें।",
        success: "फ़ाइल सफलतापूर्वक रूपांतरित!",
        categories: {
          all: "सभी फॉर्मेट",
          documents: "दस्तावेज़",
          spreadsheets: "स्प्रेडशीट",
          images: "छवियां",
          ebooks: "ई-बुक्स",
          presentations: "प्रस्तुतियां",
          data: "डेटा"
        }
      },
      history: {
        title: "रूपांतरण इतिहास",
        fileName: "फ़ाइल नाम",
        originalFormat: "मूल",
        targetFormat: "लक्ष्य",
        date: "तारीख",
        status: "स्थिति",
        actions: "क्रियाएं",
        download: "डाउनलोड",
        delete: "हटाएं",
        noHistory: "कोई रूपांतरण इतिहास नहीं",
        pending: "लंबित",
        processing: "प्रोसेसिंग",
        completed: "पूर्ण",
        failed: "विफल"
      },
      settings: {
        title: "सेटिंग्स",
        language: "भाषा",
        theme: "थीम",
        themeLight: "लाइट",
        themeDark: "डार्क",
        themeSystem: "सिस्टम",
        notifications: "नोटिफिकेशन",
        notificationsDesc: "अपने रूपांतरणों के बारे में ईमेल सूचनाएं प्राप्त करें",
        save: "परिवर्तन सहेजें",
        saved: "सेटिंग्स सफलतापूर्वक सहेजी गईं"
      },
      common: {
        loading: "लोड हो रहा है...",
        error: "त्रुटि",
        success: "सफलता",
        cancel: "रद्द करें",
        confirm: "पुष्टि करें",
        delete: "हटाएं",
        save: "सहेजें",
        back: "वापस",
        next: "अगला",
        close: "बंद करें",
        search: "खोजें",
        filter: "फ़िल्टर",
        noResults: "कोई परिणाम नहीं मिला"
      },
      footer: {
        copyright: "सर्वाधिकार सुरक्षित",
        privacy: "गोपनीयता नीति",
        terms: "सेवा की शर्तें",
        contact: "संपर्क करें"
      }
    }
  },
  fr: {
    translation: {
      nav: {
        home: "Accueil",
        convert: "Convertir",
        history: "Historique",
        settings: "Paramètres",
        logout: "Déconnexion",
        login: "Connexion",
        getStarted: "Commencer"
      },
      landing: {
        title: "Convertissez PDF en n'importe quel format",
        subtitle: "Conversion PDF rapide, sécurisée et gratuite vers plus de 50 formats. Aucune inscription requise pour les conversions de base.",
        cta: "Commencer la conversion",
        trustedBy: "Approuvé par plus de 10 000 utilisateurs dans le monde",
        features: {
          fast: "Ultra Rapide",
          fastDesc: "Convertissez des fichiers en quelques secondes avec notre moteur optimisé",
          secure: "100% Sécurisé",
          secureDesc: "Vos fichiers sont cryptés et automatiquement supprimés après conversion",
          free: "Gratuit pour toujours",
          freeDesc: "Aucun coût caché ni abonnement. Toutes les fonctionnalités de base sont gratuites",
          formats: "50+ Formats",
          formatsDesc: "Support pour documents, images, feuilles de calcul et plus"
        },
        categories: {
          documents: "Documents",
          documentsDesc: "PDF, DOCX, DOC, TXT, RTF, ODT, HTML, Markdown",
          spreadsheets: "Feuilles de calcul",
          spreadsheetsDesc: "XLSX, XLS, CSV, ODS, XML, JSON",
          images: "Images",
          imagesDesc: "PNG, JPG, GIF, TIFF, BMP, WEBP, SVG",
          ebooks: "E-Books",
          ebooksDesc: "EPUB, MOBI, AZW3, FB2",
          presentations: "Présentations",
          presentationsDesc: "PPTX, PPT, ODP",
          data: "Fichiers de données",
          dataDesc: "XML, JSON, YAML, CSV"
        },
        howItWorks: {
          title: "Comment ça marche",
          step1: "Téléchargez votre fichier",
          step1Desc: "Glissez-déposez ou cliquez pour télécharger votre PDF ou document",
          step2: "Choisissez le format",
          step2Desc: "Sélectionnez votre format de sortie parmi plus de 50 options",
          step3: "Téléchargez",
          step3Desc: "Obtenez votre fichier converti instantanément"
        }
      },
      dashboard: {
        welcome: "Bienvenue",
        recentConversions: "Conversions récentes",
        totalConversions: "Total des conversions",
        storageUsed: "Stockage utilisé",
        quickConvert: "Conversion rapide",
        viewAll: "Voir tout",
        noConversions: "Aucune conversion pour le moment",
        startConverting: "Commencez votre première conversion"
      },
      converter: {
        title: "Convertissez vos fichiers",
        dragDrop: "Glissez et déposez votre fichier ici",
        or: "ou",
        browse: "Parcourir les fichiers",
        supportedFormats: "Formats supportés: PDF, DOCX, XLSX, PNG, JPG et plus",
        maxSize: "Taille maximale du fichier: 50 Mo",
        selectFormat: "Sélectionnez le format de sortie",
        convert: "Convertir maintenant",
        converting: "Conversion en cours...",
        downloadReady: "Téléchargement prêt",
        download: "Télécharger le fichier",
        convertAnother: "Convertir un autre fichier",
        error: "La conversion a échoué. Veuillez réessayer.",
        success: "Fichier converti avec succès!",
        categories: {
          all: "Tous les formats",
          documents: "Documents",
          spreadsheets: "Feuilles de calcul",
          images: "Images",
          ebooks: "E-Books",
          presentations: "Présentations",
          data: "Données"
        }
      },
      history: {
        title: "Historique des conversions",
        fileName: "Nom du fichier",
        originalFormat: "Original",
        targetFormat: "Cible",
        date: "Date",
        status: "Statut",
        actions: "Actions",
        download: "Télécharger",
        delete: "Supprimer",
        noHistory: "Aucun historique de conversion",
        pending: "En attente",
        processing: "En cours",
        completed: "Terminé",
        failed: "Échoué"
      },
      settings: {
        title: "Paramètres",
        language: "Langue",
        theme: "Thème",
        themeLight: "Clair",
        themeDark: "Sombre",
        themeSystem: "Système",
        notifications: "Notifications",
        notificationsDesc: "Recevoir des notifications par email concernant vos conversions",
        save: "Enregistrer les modifications",
        saved: "Paramètres enregistrés avec succès"
      },
      common: {
        loading: "Chargement...",
        error: "Erreur",
        success: "Succès",
        cancel: "Annuler",
        confirm: "Confirmer",
        delete: "Supprimer",
        save: "Enregistrer",
        back: "Retour",
        next: "Suivant",
        close: "Fermer",
        search: "Rechercher",
        filter: "Filtrer",
        noResults: "Aucun résultat trouvé"
      },
      footer: {
        copyright: "Tous droits réservés",
        privacy: "Politique de confidentialité",
        terms: "Conditions d'utilisation",
        contact: "Contactez-nous"
      }
    }
  },
  es: {
    translation: {
      nav: {
        home: "Inicio",
        convert: "Convertir",
        history: "Historial",
        settings: "Configuración",
        logout: "Cerrar sesión",
        login: "Iniciar sesión",
        getStarted: "Comenzar"
      },
      landing: {
        title: "Convierte PDF a cualquier formato",
        subtitle: "Conversión de PDF rápida, segura y gratuita a más de 50 formatos. Sin necesidad de registro para conversiones básicas.",
        cta: "Comenzar a convertir",
        trustedBy: "Confiado por más de 10,000 usuarios en todo el mundo",
        features: {
          fast: "Ultra Rápido",
          fastDesc: "Convierte archivos en segundos con nuestro motor de procesamiento optimizado",
          secure: "100% Seguro",
          secureDesc: "Tus archivos están encriptados y se eliminan automáticamente después de la conversión",
          free: "Gratis para siempre",
          freeDesc: "Sin costos ocultos ni suscripciones. Todas las funciones básicas son gratuitas",
          formats: "50+ Formatos",
          formatsDesc: "Soporte para documentos, imágenes, hojas de cálculo y más"
        },
        categories: {
          documents: "Documentos",
          documentsDesc: "PDF, DOCX, DOC, TXT, RTF, ODT, HTML, Markdown",
          spreadsheets: "Hojas de cálculo",
          spreadsheetsDesc: "XLSX, XLS, CSV, ODS, XML, JSON",
          images: "Imágenes",
          imagesDesc: "PNG, JPG, GIF, TIFF, BMP, WEBP, SVG",
          ebooks: "E-Books",
          ebooksDesc: "EPUB, MOBI, AZW3, FB2",
          presentations: "Presentaciones",
          presentationsDesc: "PPTX, PPT, ODP",
          data: "Archivos de datos",
          dataDesc: "XML, JSON, YAML, CSV"
        },
        howItWorks: {
          title: "Cómo funciona",
          step1: "Sube tu archivo",
          step1Desc: "Arrastra y suelta o haz clic para subir tu PDF o documento",
          step2: "Elige el formato",
          step2Desc: "Selecciona el formato de salida deseado de más de 50 opciones",
          step3: "Descarga",
          step3Desc: "Obtén tu archivo convertido al instante"
        }
      },
      dashboard: {
        welcome: "Bienvenido de nuevo",
        recentConversions: "Conversiones recientes",
        totalConversions: "Total de conversiones",
        storageUsed: "Almacenamiento usado",
        quickConvert: "Conversión rápida",
        viewAll: "Ver todo",
        noConversions: "Sin conversiones aún",
        startConverting: "Comienza tu primera conversión"
      },
      converter: {
        title: "Convierte tus archivos",
        dragDrop: "Arrastra y suelta tu archivo aquí",
        or: "o",
        browse: "Explorar archivos",
        supportedFormats: "Formatos soportados: PDF, DOCX, XLSX, PNG, JPG y más",
        maxSize: "Tamaño máximo de archivo: 50MB",
        selectFormat: "Selecciona el formato de salida",
        convert: "Convertir ahora",
        converting: "Convirtiendo...",
        downloadReady: "Descarga lista",
        download: "Descargar archivo",
        convertAnother: "Convertir otro archivo",
        error: "La conversión falló. Por favor intenta de nuevo.",
        success: "¡Archivo convertido con éxito!",
        categories: {
          all: "Todos los formatos",
          documents: "Documentos",
          spreadsheets: "Hojas de cálculo",
          images: "Imágenes",
          ebooks: "E-Books",
          presentations: "Presentaciones",
          data: "Datos"
        }
      },
      history: {
        title: "Historial de conversiones",
        fileName: "Nombre del archivo",
        originalFormat: "Original",
        targetFormat: "Destino",
        date: "Fecha",
        status: "Estado",
        actions: "Acciones",
        download: "Descargar",
        delete: "Eliminar",
        noHistory: "Sin historial de conversiones",
        pending: "Pendiente",
        processing: "Procesando",
        completed: "Completado",
        failed: "Fallido"
      },
      settings: {
        title: "Configuración",
        language: "Idioma",
        theme: "Tema",
        themeLight: "Claro",
        themeDark: "Oscuro",
        themeSystem: "Sistema",
        notifications: "Notificaciones",
        notificationsDesc: "Recibir notificaciones por email sobre tus conversiones",
        save: "Guardar cambios",
        saved: "Configuración guardada con éxito"
      },
      common: {
        loading: "Cargando...",
        error: "Error",
        success: "Éxito",
        cancel: "Cancelar",
        confirm: "Confirmar",
        delete: "Eliminar",
        save: "Guardar",
        back: "Atrás",
        next: "Siguiente",
        close: "Cerrar",
        search: "Buscar",
        filter: "Filtrar",
        noResults: "No se encontraron resultados"
      },
      footer: {
        copyright: "Todos los derechos reservados",
        privacy: "Política de privacidad",
        terms: "Términos de servicio",
        contact: "Contáctenos"
      }
    }
  },
  de: {
    translation: {
      nav: {
        home: "Startseite",
        convert: "Konvertieren",
        history: "Verlauf",
        settings: "Einstellungen",
        logout: "Abmelden",
        login: "Anmelden",
        getStarted: "Loslegen"
      },
      landing: {
        title: "PDF in jedes Format konvertieren",
        subtitle: "Schnelle, sichere und kostenlose PDF-Konvertierung in über 50 Formate. Keine Registrierung für Basiskonvertierungen erforderlich.",
        cta: "Jetzt mit der Konvertierung beginnen",
        trustedBy: "Von über 10.000 Nutzern weltweit vertraut",
        features: {
          fast: "Blitzschnell",
          fastDesc: "Konvertieren Sie Dateien in Sekunden mit unserer optimierten Verarbeitungs-Engine",
          secure: "100% Sicher",
          secureDesc: "Ihre Dateien werden verschlüsselt und nach der Konvertierung automatisch gelöscht",
          free: "Für immer kostenlos",
          freeDesc: "Keine versteckten Kosten oder Abonnements. Alle Basisfunktionen sind kostenlos",
          formats: "50+ Formate",
          formatsDesc: "Unterstützung für Dokumente, Bilder, Tabellenkalkulationen und mehr"
        },
        categories: {
          documents: "Dokumente",
          documentsDesc: "PDF, DOCX, DOC, TXT, RTF, ODT, HTML, Markdown",
          spreadsheets: "Tabellenkalkulationen",
          spreadsheetsDesc: "XLSX, XLS, CSV, ODS, XML, JSON",
          images: "Bilder",
          imagesDesc: "PNG, JPG, GIF, TIFF, BMP, WEBP, SVG",
          ebooks: "E-Books",
          ebooksDesc: "EPUB, MOBI, AZW3, FB2",
          presentations: "Präsentationen",
          presentationsDesc: "PPTX, PPT, ODP",
          data: "Datendateien",
          dataDesc: "XML, JSON, YAML, CSV"
        },
        howItWorks: {
          title: "So funktioniert es",
          step1: "Datei hochladen",
          step1Desc: "Ziehen und ablegen oder klicken, um Ihr PDF oder Dokument hochzuladen",
          step2: "Format wählen",
          step2Desc: "Wählen Sie Ihr gewünschtes Ausgabeformat aus über 50 Optionen",
          step3: "Herunterladen",
          step3Desc: "Erhalten Sie Ihre konvertierte Datei sofort"
        }
      },
      dashboard: {
        welcome: "Willkommen zurück",
        recentConversions: "Neueste Konvertierungen",
        totalConversions: "Gesamte Konvertierungen",
        storageUsed: "Speicher verwendet",
        quickConvert: "Schnellkonvertierung",
        viewAll: "Alle anzeigen",
        noConversions: "Noch keine Konvertierungen",
        startConverting: "Starten Sie Ihre erste Konvertierung"
      },
      converter: {
        title: "Konvertieren Sie Ihre Dateien",
        dragDrop: "Ziehen und legen Sie Ihre Datei hier ab",
        or: "oder",
        browse: "Dateien durchsuchen",
        supportedFormats: "Unterstützte Formate: PDF, DOCX, XLSX, PNG, JPG und mehr",
        maxSize: "Maximale Dateigröße: 50MB",
        selectFormat: "Ausgabeformat auswählen",
        convert: "Jetzt konvertieren",
        converting: "Konvertiere...",
        downloadReady: "Download bereit",
        download: "Datei herunterladen",
        convertAnother: "Weitere Datei konvertieren",
        error: "Konvertierung fehlgeschlagen. Bitte versuchen Sie es erneut.",
        success: "Datei erfolgreich konvertiert!",
        categories: {
          all: "Alle Formate",
          documents: "Dokumente",
          spreadsheets: "Tabellenkalkulationen",
          images: "Bilder",
          ebooks: "E-Books",
          presentations: "Präsentationen",
          data: "Daten"
        }
      },
      history: {
        title: "Konvertierungsverlauf",
        fileName: "Dateiname",
        originalFormat: "Original",
        targetFormat: "Ziel",
        date: "Datum",
        status: "Status",
        actions: "Aktionen",
        download: "Herunterladen",
        delete: "Löschen",
        noHistory: "Kein Konvertierungsverlauf",
        pending: "Ausstehend",
        processing: "Verarbeitung",
        completed: "Abgeschlossen",
        failed: "Fehlgeschlagen"
      },
      settings: {
        title: "Einstellungen",
        language: "Sprache",
        theme: "Thema",
        themeLight: "Hell",
        themeDark: "Dunkel",
        themeSystem: "System",
        notifications: "Benachrichtigungen",
        notificationsDesc: "E-Mail-Benachrichtigungen über Ihre Konvertierungen erhalten",
        save: "Änderungen speichern",
        saved: "Einstellungen erfolgreich gespeichert"
      },
      common: {
        loading: "Laden...",
        error: "Fehler",
        success: "Erfolg",
        cancel: "Abbrechen",
        confirm: "Bestätigen",
        delete: "Löschen",
        save: "Speichern",
        back: "Zurück",
        next: "Weiter",
        close: "Schließen",
        search: "Suchen",
        filter: "Filtern",
        noResults: "Keine Ergebnisse gefunden"
      },
      footer: {
        copyright: "Alle Rechte vorbehalten",
        privacy: "Datenschutzrichtlinie",
        terms: "Nutzungsbedingungen",
        contact: "Kontakt"
      }
    }
  },
  pt: {
    translation: {
      nav: {
        home: "Início",
        convert: "Converter",
        history: "Histórico",
        settings: "Configurações",
        logout: "Sair",
        login: "Entrar",
        getStarted: "Começar"
      },
      landing: {
        title: "Converta PDF para qualquer formato",
        subtitle: "Conversão de PDF rápida, segura e gratuita para mais de 50 formatos. Sem necessidade de cadastro para conversões básicas.",
        cta: "Começar a converter agora",
        trustedBy: "Confiado por mais de 10.000 usuários em todo o mundo",
        features: {
          fast: "Ultra Rápido",
          fastDesc: "Converta arquivos em segundos com nosso motor de processamento otimizado",
          secure: "100% Seguro",
          secureDesc: "Seus arquivos são criptografados e excluídos automaticamente após a conversão",
          free: "Grátis para sempre",
          freeDesc: "Sem custos ocultos ou assinaturas. Todos os recursos básicos são gratuitos",
          formats: "50+ Formatos",
          formatsDesc: "Suporte para documentos, imagens, planilhas e mais"
        },
        categories: {
          documents: "Documentos",
          documentsDesc: "PDF, DOCX, DOC, TXT, RTF, ODT, HTML, Markdown",
          spreadsheets: "Planilhas",
          spreadsheetsDesc: "XLSX, XLS, CSV, ODS, XML, JSON",
          images: "Imagens",
          imagesDesc: "PNG, JPG, GIF, TIFF, BMP, WEBP, SVG",
          ebooks: "E-Books",
          ebooksDesc: "EPUB, MOBI, AZW3, FB2",
          presentations: "Apresentações",
          presentationsDesc: "PPTX, PPT, ODP",
          data: "Arquivos de dados",
          dataDesc: "XML, JSON, YAML, CSV"
        },
        howItWorks: {
          title: "Como funciona",
          step1: "Envie seu arquivo",
          step1Desc: "Arraste e solte ou clique para enviar seu PDF ou documento",
          step2: "Escolha o formato",
          step2Desc: "Selecione o formato de saída desejado de mais de 50 opções",
          step3: "Baixe",
          step3Desc: "Obtenha seu arquivo convertido instantaneamente"
        }
      },
      dashboard: {
        welcome: "Bem-vindo de volta",
        recentConversions: "Conversões recentes",
        totalConversions: "Total de conversões",
        storageUsed: "Armazenamento usado",
        quickConvert: "Conversão rápida",
        viewAll: "Ver tudo",
        noConversions: "Sem conversões ainda",
        startConverting: "Comece sua primeira conversão"
      },
      converter: {
        title: "Converta seus arquivos",
        dragDrop: "Arraste e solte seu arquivo aqui",
        or: "ou",
        browse: "Procurar arquivos",
        supportedFormats: "Formatos suportados: PDF, DOCX, XLSX, PNG, JPG e mais",
        maxSize: "Tamanho máximo do arquivo: 50MB",
        selectFormat: "Selecione o formato de saída",
        convert: "Converter agora",
        converting: "Convertendo...",
        downloadReady: "Download pronto",
        download: "Baixar arquivo",
        convertAnother: "Converter outro arquivo",
        error: "A conversão falhou. Por favor, tente novamente.",
        success: "Arquivo convertido com sucesso!",
        categories: {
          all: "Todos os formatos",
          documents: "Documentos",
          spreadsheets: "Planilhas",
          images: "Imagens",
          ebooks: "E-Books",
          presentations: "Apresentações",
          data: "Dados"
        }
      },
      history: {
        title: "Histórico de conversões",
        fileName: "Nome do arquivo",
        originalFormat: "Original",
        targetFormat: "Destino",
        date: "Data",
        status: "Status",
        actions: "Ações",
        download: "Baixar",
        delete: "Excluir",
        noHistory: "Sem histórico de conversões",
        pending: "Pendente",
        processing: "Processando",
        completed: "Concluído",
        failed: "Falhou"
      },
      settings: {
        title: "Configurações",
        language: "Idioma",
        theme: "Tema",
        themeLight: "Claro",
        themeDark: "Escuro",
        themeSystem: "Sistema",
        notifications: "Notificações",
        notificationsDesc: "Receber notificações por email sobre suas conversões",
        save: "Salvar alterações",
        saved: "Configurações salvas com sucesso"
      },
      common: {
        loading: "Carregando...",
        error: "Erro",
        success: "Sucesso",
        cancel: "Cancelar",
        confirm: "Confirmar",
        delete: "Excluir",
        save: "Salvar",
        back: "Voltar",
        next: "Próximo",
        close: "Fechar",
        search: "Pesquisar",
        filter: "Filtrar",
        noResults: "Nenhum resultado encontrado"
      },
      footer: {
        copyright: "Todos os direitos reservados",
        privacy: "Política de Privacidade",
        terms: "Termos de Serviço",
        contact: "Contate-nos"
      }
    }
  },
  zh: {
    translation: {
      nav: {
        home: "首页",
        convert: "转换",
        history: "历史",
        settings: "设置",
        logout: "退出",
        login: "登录",
        getStarted: "开始"
      },
      landing: {
        title: "将PDF转换为任何格式",
        subtitle: "快速、安全且免费的PDF转换，支持50多种格式。基本转换无需注册。",
        cta: "立即开始转换",
        trustedBy: "全球超过10,000名用户信赖",
        features: {
          fast: "闪电般快速",
          fastDesc: "使用我们优化的处理引擎在几秒内转换文件",
          secure: "100%安全",
          secureDesc: "您的文件已加密，转换后自动删除",
          free: "永久免费",
          freeDesc: "没有隐藏费用或订阅。所有基本功能免费",
          formats: "50多种格式",
          formatsDesc: "支持文档、图片、电子表格等"
        },
        categories: {
          documents: "文档",
          documentsDesc: "PDF, DOCX, DOC, TXT, RTF, ODT, HTML, Markdown",
          spreadsheets: "电子表格",
          spreadsheetsDesc: "XLSX, XLS, CSV, ODS, XML, JSON",
          images: "图片",
          imagesDesc: "PNG, JPG, GIF, TIFF, BMP, WEBP, SVG",
          ebooks: "电子书",
          ebooksDesc: "EPUB, MOBI, AZW3, FB2",
          presentations: "演示文稿",
          presentationsDesc: "PPTX, PPT, ODP",
          data: "数据文件",
          dataDesc: "XML, JSON, YAML, CSV"
        },
        howItWorks: {
          title: "如何使用",
          step1: "上传文件",
          step1Desc: "拖放或点击上传您的PDF或文档",
          step2: "选择格式",
          step2Desc: "从50多个选项中选择所需的输出格式",
          step3: "下载",
          step3Desc: "立即获取转换后的文件"
        }
      },
      dashboard: {
        welcome: "欢迎回来",
        recentConversions: "最近转换",
        totalConversions: "总转换次数",
        storageUsed: "已用存储",
        quickConvert: "快速转换",
        viewAll: "查看全部",
        noConversions: "暂无转换记录",
        startConverting: "开始您的第一次转换"
      },
      converter: {
        title: "转换您的文件",
        dragDrop: "将文件拖放到这里",
        or: "或",
        browse: "浏览文件",
        supportedFormats: "支持的格式：PDF, DOCX, XLSX, PNG, JPG等",
        maxSize: "最大文件大小：50MB",
        selectFormat: "选择输出格式",
        convert: "立即转换",
        converting: "转换中...",
        downloadReady: "下载准备就绪",
        download: "下载文件",
        convertAnother: "转换另一个文件",
        error: "转换失败。请重试。",
        success: "文件转换成功！",
        categories: {
          all: "所有格式",
          documents: "文档",
          spreadsheets: "电子表格",
          images: "图片",
          ebooks: "电子书",
          presentations: "演示文稿",
          data: "数据"
        }
      },
      history: {
        title: "转换历史",
        fileName: "文件名",
        originalFormat: "原格式",
        targetFormat: "目标格式",
        date: "日期",
        status: "状态",
        actions: "操作",
        download: "下载",
        delete: "删除",
        noHistory: "暂无转换历史",
        pending: "待处理",
        processing: "处理中",
        completed: "已完成",
        failed: "失败"
      },
      settings: {
        title: "设置",
        language: "语言",
        theme: "主题",
        themeLight: "浅色",
        themeDark: "深色",
        themeSystem: "跟随系统",
        notifications: "通知",
        notificationsDesc: "接收有关转换的电子邮件通知",
        save: "保存更改",
        saved: "设置保存成功"
      },
      common: {
        loading: "加载中...",
        error: "错误",
        success: "成功",
        cancel: "取消",
        confirm: "确认",
        delete: "删除",
        save: "保存",
        back: "返回",
        next: "下一步",
        close: "关闭",
        search: "搜索",
        filter: "筛选",
        noResults: "未找到结果"
      },
      footer: {
        copyright: "版权所有",
        privacy: "隐私政策",
        terms: "服务条款",
        contact: "联系我们"
      }
    }
  },
  ja: {
    translation: {
      nav: {
        home: "ホーム",
        convert: "変換",
        history: "履歴",
        settings: "設定",
        logout: "ログアウト",
        login: "ログイン",
        getStarted: "始める"
      },
      landing: {
        title: "PDFを任意の形式に変換",
        subtitle: "50以上の形式への高速で安全な無料PDF変換。基本的な変換には登録不要。",
        cta: "今すぐ変換を開始",
        trustedBy: "世界中の10,000人以上のユーザーに信頼されています",
        features: {
          fast: "超高速",
          fastDesc: "最適化された処理エンジンで数秒でファイルを変換",
          secure: "100%安全",
          secureDesc: "ファイルは暗号化され、変換後に自動的に削除されます",
          free: "永久無料",
          freeDesc: "隠れた費用やサブスクリプションはありません。すべての基本機能が無料",
          formats: "50以上の形式",
          formatsDesc: "ドキュメント、画像、スプレッドシートなどに対応"
        },
        categories: {
          documents: "ドキュメント",
          documentsDesc: "PDF, DOCX, DOC, TXT, RTF, ODT, HTML, Markdown",
          spreadsheets: "スプレッドシート",
          spreadsheetsDesc: "XLSX, XLS, CSV, ODS, XML, JSON",
          images: "画像",
          imagesDesc: "PNG, JPG, GIF, TIFF, BMP, WEBP, SVG",
          ebooks: "電子書籍",
          ebooksDesc: "EPUB, MOBI, AZW3, FB2",
          presentations: "プレゼンテーション",
          presentationsDesc: "PPTX, PPT, ODP",
          data: "データファイル",
          dataDesc: "XML, JSON, YAML, CSV"
        },
        howItWorks: {
          title: "使い方",
          step1: "ファイルをアップロード",
          step1Desc: "PDFまたはドキュメントをドラッグ＆ドロップまたはクリックしてアップロード",
          step2: "形式を選択",
          step2Desc: "50以上のオプションから希望の出力形式を選択",
          step3: "ダウンロード",
          step3Desc: "変換されたファイルを即座に取得"
        }
      },
      dashboard: {
        welcome: "おかえりなさい",
        recentConversions: "最近の変換",
        totalConversions: "変換総数",
        storageUsed: "使用ストレージ",
        quickConvert: "クイック変換",
        viewAll: "すべて表示",
        noConversions: "まだ変換がありません",
        startConverting: "最初の変換を始めましょう"
      },
      converter: {
        title: "ファイルを変換",
        dragDrop: "ここにファイルをドラッグ＆ドロップ",
        or: "または",
        browse: "ファイルを参照",
        supportedFormats: "対応形式：PDF, DOCX, XLSX, PNG, JPGなど",
        maxSize: "最大ファイルサイズ：50MB",
        selectFormat: "出力形式を選択",
        convert: "今すぐ変換",
        converting: "変換中...",
        downloadReady: "ダウンロード準備完了",
        download: "ファイルをダウンロード",
        convertAnother: "別のファイルを変換",
        error: "変換に失敗しました。もう一度お試しください。",
        success: "ファイルの変換に成功しました！",
        categories: {
          all: "すべての形式",
          documents: "ドキュメント",
          spreadsheets: "スプレッドシート",
          images: "画像",
          ebooks: "電子書籍",
          presentations: "プレゼンテーション",
          data: "データ"
        }
      },
      history: {
        title: "変換履歴",
        fileName: "ファイル名",
        originalFormat: "元の形式",
        targetFormat: "変換先",
        date: "日付",
        status: "ステータス",
        actions: "アクション",
        download: "ダウンロード",
        delete: "削除",
        noHistory: "変換履歴がありません",
        pending: "保留中",
        processing: "処理中",
        completed: "完了",
        failed: "失敗"
      },
      settings: {
        title: "設定",
        language: "言語",
        theme: "テーマ",
        themeLight: "ライト",
        themeDark: "ダーク",
        themeSystem: "システム",
        notifications: "通知",
        notificationsDesc: "変換に関するメール通知を受け取る",
        save: "変更を保存",
        saved: "設定が正常に保存されました"
      },
      common: {
        loading: "読み込み中...",
        error: "エラー",
        success: "成功",
        cancel: "キャンセル",
        confirm: "確認",
        delete: "削除",
        save: "保存",
        back: "戻る",
        next: "次へ",
        close: "閉じる",
        search: "検索",
        filter: "フィルター",
        noResults: "結果が見つかりません"
      },
      footer: {
        copyright: "全著作権所有",
        privacy: "プライバシーポリシー",
        terms: "利用規約",
        contact: "お問い合わせ"
      }
    }
  },
  ko: {
    translation: {
      nav: {
        home: "홈",
        convert: "변환",
        history: "기록",
        settings: "설정",
        logout: "로그아웃",
        login: "로그인",
        getStarted: "시작하기"
      },
      landing: {
        title: "PDF를 모든 형식으로 변환",
        subtitle: "50개 이상의 형식으로 빠르고 안전한 무료 PDF 변환. 기본 변환에는 등록이 필요 없습니다.",
        cta: "지금 변환 시작",
        trustedBy: "전 세계 10,000명 이상의 사용자가 신뢰합니다",
        features: {
          fast: "번개처럼 빠름",
          fastDesc: "최적화된 처리 엔진으로 몇 초 만에 파일 변환",
          secure: "100% 안전",
          secureDesc: "파일은 암호화되고 변환 후 자동으로 삭제됩니다",
          free: "영원히 무료",
          freeDesc: "숨겨진 비용이나 구독 없음. 모든 기본 기능이 무료",
          formats: "50개 이상의 형식",
          formatsDesc: "문서, 이미지, 스프레드시트 등 지원"
        },
        categories: {
          documents: "문서",
          documentsDesc: "PDF, DOCX, DOC, TXT, RTF, ODT, HTML, Markdown",
          spreadsheets: "스프레드시트",
          spreadsheetsDesc: "XLSX, XLS, CSV, ODS, XML, JSON",
          images: "이미지",
          imagesDesc: "PNG, JPG, GIF, TIFF, BMP, WEBP, SVG",
          ebooks: "전자책",
          ebooksDesc: "EPUB, MOBI, AZW3, FB2",
          presentations: "프레젠테이션",
          presentationsDesc: "PPTX, PPT, ODP",
          data: "데이터 파일",
          dataDesc: "XML, JSON, YAML, CSV"
        },
        howItWorks: {
          title: "사용 방법",
          step1: "파일 업로드",
          step1Desc: "PDF 또는 문서를 드래그 앤 드롭하거나 클릭하여 업로드",
          step2: "형식 선택",
          step2Desc: "50개 이상의 옵션에서 원하는 출력 형식 선택",
          step3: "다운로드",
          step3Desc: "변환된 파일을 즉시 받기"
        }
      },
      dashboard: {
        welcome: "환영합니다",
        recentConversions: "최근 변환",
        totalConversions: "총 변환 수",
        storageUsed: "사용된 저장공간",
        quickConvert: "빠른 변환",
        viewAll: "모두 보기",
        noConversions: "아직 변환이 없습니다",
        startConverting: "첫 번째 변환을 시작하세요"
      },
      converter: {
        title: "파일 변환",
        dragDrop: "파일을 여기에 드래그 앤 드롭하세요",
        or: "또는",
        browse: "파일 찾아보기",
        supportedFormats: "지원 형식: PDF, DOCX, XLSX, PNG, JPG 등",
        maxSize: "최대 파일 크기: 50MB",
        selectFormat: "출력 형식 선택",
        convert: "지금 변환",
        converting: "변환 중...",
        downloadReady: "다운로드 준비됨",
        download: "파일 다운로드",
        convertAnother: "다른 파일 변환",
        error: "변환 실패. 다시 시도해 주세요.",
        success: "파일이 성공적으로 변환되었습니다!",
        categories: {
          all: "모든 형식",
          documents: "문서",
          spreadsheets: "스프레드시트",
          images: "이미지",
          ebooks: "전자책",
          presentations: "프레젠테이션",
          data: "데이터"
        }
      },
      history: {
        title: "변환 기록",
        fileName: "파일 이름",
        originalFormat: "원본",
        targetFormat: "대상",
        date: "날짜",
        status: "상태",
        actions: "작업",
        download: "다운로드",
        delete: "삭제",
        noHistory: "변환 기록이 없습니다",
        pending: "대기 중",
        processing: "처리 중",
        completed: "완료",
        failed: "실패"
      },
      settings: {
        title: "설정",
        language: "언어",
        theme: "테마",
        themeLight: "라이트",
        themeDark: "다크",
        themeSystem: "시스템",
        notifications: "알림",
        notificationsDesc: "변환에 대한 이메일 알림 받기",
        save: "변경사항 저장",
        saved: "설정이 성공적으로 저장되었습니다"
      },
      common: {
        loading: "로딩 중...",
        error: "오류",
        success: "성공",
        cancel: "취소",
        confirm: "확인",
        delete: "삭제",
        save: "저장",
        back: "뒤로",
        next: "다음",
        close: "닫기",
        search: "검색",
        filter: "필터",
        noResults: "결과를 찾을 수 없습니다"
      },
      footer: {
        copyright: "All rights reserved",
        privacy: "개인정보 처리방침",
        terms: "서비스 약관",
        contact: "문의하기"
      }
    }
  },
  ru: {
    translation: {
      nav: {
        home: "Главная",
        convert: "Конвертировать",
        history: "История",
        settings: "Настройки",
        logout: "Выйти",
        login: "Войти",
        getStarted: "Начать"
      },
      landing: {
        title: "Конвертируйте PDF в любой формат",
        subtitle: "Быстрое, безопасное и бесплатное преобразование PDF в более чем 50 форматов. Регистрация не требуется для базовых конвертаций.",
        cta: "Начать конвертацию",
        trustedBy: "Доверяют более 10 000 пользователей по всему миру",
        features: {
          fast: "Молниеносная скорость",
          fastDesc: "Конвертируйте файлы за секунды с нашим оптимизированным движком",
          secure: "100% безопасность",
          secureDesc: "Ваши файлы зашифрованы и автоматически удаляются после конвертации",
          free: "Бесплатно навсегда",
          freeDesc: "Никаких скрытых расходов или подписок. Все базовые функции бесплатны",
          formats: "50+ форматов",
          formatsDesc: "Поддержка документов, изображений, таблиц и многого другого"
        },
        categories: {
          documents: "Документы",
          documentsDesc: "PDF, DOCX, DOC, TXT, RTF, ODT, HTML, Markdown",
          spreadsheets: "Таблицы",
          spreadsheetsDesc: "XLSX, XLS, CSV, ODS, XML, JSON",
          images: "Изображения",
          imagesDesc: "PNG, JPG, GIF, TIFF, BMP, WEBP, SVG",
          ebooks: "Электронные книги",
          ebooksDesc: "EPUB, MOBI, AZW3, FB2",
          presentations: "Презентации",
          presentationsDesc: "PPTX, PPT, ODP",
          data: "Файлы данных",
          dataDesc: "XML, JSON, YAML, CSV"
        },
        howItWorks: {
          title: "Как это работает",
          step1: "Загрузите файл",
          step1Desc: "Перетащите или нажмите для загрузки PDF или документа",
          step2: "Выберите формат",
          step2Desc: "Выберите нужный формат вывода из 50+ вариантов",
          step3: "Скачайте",
          step3Desc: "Мгновенно получите преобразованный файл"
        }
      },
      dashboard: {
        welcome: "С возвращением",
        recentConversions: "Недавние конвертации",
        totalConversions: "Всего конвертаций",
        storageUsed: "Использовано хранилища",
        quickConvert: "Быстрая конвертация",
        viewAll: "Показать все",
        noConversions: "Пока нет конвертаций",
        startConverting: "Начните первую конвертацию"
      },
      converter: {
        title: "Конвертируйте файлы",
        dragDrop: "Перетащите файл сюда",
        or: "или",
        browse: "Выбрать файлы",
        supportedFormats: "Поддерживаемые форматы: PDF, DOCX, XLSX, PNG, JPG и другие",
        maxSize: "Максимальный размер файла: 50МБ",
        selectFormat: "Выберите формат вывода",
        convert: "Конвертировать",
        converting: "Конвертация...",
        downloadReady: "Готово к скачиванию",
        download: "Скачать файл",
        convertAnother: "Конвертировать другой файл",
        error: "Конвертация не удалась. Попробуйте снова.",
        success: "Файл успешно конвертирован!",
        categories: {
          all: "Все форматы",
          documents: "Документы",
          spreadsheets: "Таблицы",
          images: "Изображения",
          ebooks: "Электронные книги",
          presentations: "Презентации",
          data: "Данные"
        }
      },
      history: {
        title: "История конвертаций",
        fileName: "Имя файла",
        originalFormat: "Исходный",
        targetFormat: "Целевой",
        date: "Дата",
        status: "Статус",
        actions: "Действия",
        download: "Скачать",
        delete: "Удалить",
        noHistory: "Нет истории конвертаций",
        pending: "В ожидании",
        processing: "Обработка",
        completed: "Завершено",
        failed: "Ошибка"
      },
      settings: {
        title: "Настройки",
        language: "Язык",
        theme: "Тема",
        themeLight: "Светлая",
        themeDark: "Темная",
        themeSystem: "Системная",
        notifications: "Уведомления",
        notificationsDesc: "Получать уведомления по email о ваших конвертациях",
        save: "Сохранить изменения",
        saved: "Настройки успешно сохранены"
      },
      common: {
        loading: "Загрузка...",
        error: "Ошибка",
        success: "Успех",
        cancel: "Отмена",
        confirm: "Подтвердить",
        delete: "Удалить",
        save: "Сохранить",
        back: "Назад",
        next: "Далее",
        close: "Закрыть",
        search: "Поиск",
        filter: "Фильтр",
        noResults: "Результаты не найдены"
      },
      footer: {
        copyright: "Все права защищены",
        privacy: "Политика конфиденциальности",
        terms: "Условия использования",
        contact: "Связаться с нами"
      }
    }
  },
  tr: {
    translation: {
      nav: {
        home: "Ana Sayfa",
        convert: "Dönüştür",
        history: "Geçmiş",
        settings: "Ayarlar",
        logout: "Çıkış Yap",
        login: "Giriş Yap",
        getStarted: "Başla"
      },
      landing: {
        title: "PDF'yi Herhangi Bir Formata Dönüştürün",
        subtitle: "50'den fazla formata hızlı, güvenli ve ücretsiz PDF dönüştürme. Temel dönüştürmeler için kayıt gerekmez.",
        cta: "Şimdi Dönüştürmeye Başla",
        trustedBy: "Dünya çapında 10.000'den fazla kullanıcının güvendiği",
        features: {
          fast: "Yıldırım Hızında",
          fastDesc: "Optimize edilmiş işleme motorumuzla dosyaları saniyeler içinde dönüştürün",
          secure: "%100 Güvenli",
          secureDesc: "Dosyalarınız şifrelenir ve dönüştürmeden sonra otomatik olarak silinir",
          free: "Sonsuza Kadar Ücretsiz",
          freeDesc: "Gizli maliyet veya abonelik yok. Tüm temel özellikler ücretsiz",
          formats: "50+ Format",
          formatsDesc: "Belgeler, resimler, elektronik tablolar ve daha fazlası için destek"
        },
        categories: {
          documents: "Belgeler",
          documentsDesc: "PDF, DOCX, DOC, TXT, RTF, ODT, HTML, Markdown",
          spreadsheets: "Elektronik Tablolar",
          spreadsheetsDesc: "XLSX, XLS, CSV, ODS, XML, JSON",
          images: "Resimler",
          imagesDesc: "PNG, JPG, GIF, TIFF, BMP, WEBP, SVG",
          ebooks: "E-Kitaplar",
          ebooksDesc: "EPUB, MOBI, AZW3, FB2",
          presentations: "Sunumlar",
          presentationsDesc: "PPTX, PPT, ODP",
          data: "Veri Dosyaları",
          dataDesc: "XML, JSON, YAML, CSV"
        },
        howItWorks: {
          title: "Nasıl Çalışır",
          step1: "Dosyanızı Yükleyin",
          step1Desc: "PDF veya belgenizi yüklemek için sürükleyip bırakın veya tıklayın",
          step2: "Format Seçin",
          step2Desc: "50'den fazla seçenek arasından istediğiniz çıktı formatını seçin",
          step3: "İndirin",
          step3Desc: "Dönüştürülmüş dosyanızı anında alın"
        }
      },
      dashboard: {
        welcome: "Tekrar Hoş Geldiniz",
        recentConversions: "Son Dönüştürmeler",
        totalConversions: "Toplam Dönüştürme",
        storageUsed: "Kullanılan Depolama",
        quickConvert: "Hızlı Dönüştürme",
        viewAll: "Tümünü Gör",
        noConversions: "Henüz dönüştürme yok",
        startConverting: "İlk dönüştürmenizi başlatın"
      },
      converter: {
        title: "Dosyalarınızı Dönüştürün",
        dragDrop: "Dosyanızı buraya sürükleyip bırakın",
        or: "veya",
        browse: "Dosyalara Göz At",
        supportedFormats: "Desteklenen formatlar: PDF, DOCX, XLSX, PNG, JPG ve daha fazlası",
        maxSize: "Maksimum dosya boyutu: 50MB",
        selectFormat: "Çıktı Formatı Seçin",
        convert: "Şimdi Dönüştür",
        converting: "Dönüştürülüyor...",
        downloadReady: "İndirme Hazır",
        download: "Dosyayı İndir",
        convertAnother: "Başka Dosya Dönüştür",
        error: "Dönüştürme başarısız oldu. Lütfen tekrar deneyin.",
        success: "Dosya başarıyla dönüştürüldü!",
        categories: {
          all: "Tüm Formatlar",
          documents: "Belgeler",
          spreadsheets: "Tablolar",
          images: "Resimler",
          ebooks: "E-Kitaplar",
          presentations: "Sunumlar",
          data: "Veri"
        }
      },
      history: {
        title: "Dönüştürme Geçmişi",
        fileName: "Dosya Adı",
        originalFormat: "Orijinal",
        targetFormat: "Hedef",
        date: "Tarih",
        status: "Durum",
        actions: "İşlemler",
        download: "İndir",
        delete: "Sil",
        noHistory: "Dönüştürme geçmişi yok",
        pending: "Bekliyor",
        processing: "İşleniyor",
        completed: "Tamamlandı",
        failed: "Başarısız"
      },
      settings: {
        title: "Ayarlar",
        language: "Dil",
        theme: "Tema",
        themeLight: "Açık",
        themeDark: "Koyu",
        themeSystem: "Sistem",
        notifications: "Bildirimler",
        notificationsDesc: "Dönüştürmeleriniz hakkında e-posta bildirimleri alın",
        save: "Değişiklikleri Kaydet",
        saved: "Ayarlar başarıyla kaydedildi"
      },
      common: {
        loading: "Yükleniyor...",
        error: "Hata",
        success: "Başarılı",
        cancel: "İptal",
        confirm: "Onayla",
        delete: "Sil",
        save: "Kaydet",
        back: "Geri",
        next: "İleri",
        close: "Kapat",
        search: "Ara",
        filter: "Filtrele",
        noResults: "Sonuç bulunamadı"
      },
      footer: {
        copyright: "Tüm hakları saklıdır",
        privacy: "Gizlilik Politikası",
        terms: "Kullanım Şartları",
        contact: "Bize Ulaşın"
      }
    }
  }
};

// RTL languages
const rtlLanguages = ['ar', 'ur', 'he', 'fa'];

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false
    },
    detection: {
      order: ['localStorage', 'navigator'],
      caches: ['localStorage']
    }
  });

// Function to check if current language is RTL
export const isRTL = (lang: string) => rtlLanguages.includes(lang);

// Language options for the selector
export const languages = [
  { code: 'en', name: 'English', nativeName: 'English', flag: 'US' },
  { code: 'ur', name: 'Urdu', nativeName: 'اردو', flag: 'PK', rtl: true },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', flag: 'SA', rtl: true },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', flag: 'IN' },
  { code: 'fr', name: 'French', nativeName: 'Français', flag: 'FR' },
  { code: 'es', name: 'Spanish', nativeName: 'Español', flag: 'ES' },
  { code: 'de', name: 'German', nativeName: 'Deutsch', flag: 'DE' },
  { code: 'pt', name: 'Portuguese', nativeName: 'Português', flag: 'BR' },
  { code: 'zh', name: 'Chinese', nativeName: '中文', flag: 'CN' },
  { code: 'ja', name: 'Japanese', nativeName: '日本語', flag: 'JP' },
  { code: 'ko', name: 'Korean', nativeName: '한국어', flag: 'KR' },
  { code: 'ru', name: 'Russian', nativeName: 'Русский', flag: 'RU' },
  { code: 'tr', name: 'Turkish', nativeName: 'Türkçe', flag: 'TR' }
];

export default i18n;
