import { useTranslation } from "react-i18next";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import {
  FileText,
  History,
  Settings,
  LogOut,
  Upload,
  Download,
  Trash2,
  ArrowRight,
  Search,
  AlertCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { ThemeToggle } from "@/components/ThemeToggle";
import { LanguageSelector } from "@/components/LanguageSelector";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Conversion } from "@shared/schema";
import { useState } from "react";

function AppSidebar() {
  const { t } = useTranslation();
  const [location] = useLocation();
  const { user } = useAuth();

  const menuItems = [
    { icon: Upload, label: t("nav.convert"), path: "/" },
    { icon: History, label: t("nav.history"), path: "/history" },
    { icon: Settings, label: t("nav.settings"), path: "/settings" },
  ];

  return (
    <Sidebar>
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <FileText className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="font-semibold text-lg">Easy PDF</span>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>{t("nav.home")}</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.path}>
                  <SidebarMenuButton
                    asChild
                    isActive={location === item.path}
                  >
                    <Link href={item.path}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.label}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="p-4">
        <div className="flex items-center gap-3 mb-4">
          <Avatar className="h-9 w-9">
            <AvatarImage src={user?.profileImageUrl || ""} className="object-cover" />
            <AvatarFallback>
              {user?.firstName?.[0] || user?.email?.[0] || "U"}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">
              {user?.firstName ? `${user.firstName} ${user.lastName || ""}`.trim() : user?.email}
            </p>
            <p className="text-xs text-muted-foreground truncate">
              {user?.email}
            </p>
          </div>
        </div>
        <Button variant="outline" className="w-full" asChild>
          <a href="/api/logout">
            <LogOut className="h-4 w-4 mr-2" />
            {t("nav.logout")}
          </a>
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}

export default function HistoryPage() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");

  const { data: conversions, isLoading } = useQuery<Conversion[]>({
    queryKey: ["/api/conversions"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/conversions/${id}`);
    },
    onSuccess: () => {
      toast({
        title: t("common.success"),
        description: "Conversion deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/conversions"] });
    },
    onError: () => {
      toast({
        title: t("common.error"),
        description: "Failed to delete conversion",
        variant: "destructive",
      });
    },
  });

  const filteredConversions = conversions?.filter((c) =>
    c.originalFileName.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString(undefined, {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge variant="default" className="bg-green-500">{t("history.completed")}</Badge>;
      case "processing":
        return <Badge variant="secondary">{t("history.processing")}</Badge>;
      case "failed":
        return <Badge variant="destructive">{t("history.failed")}</Badge>;
      default:
        return <Badge variant="outline">{t("history.pending")}</Badge>;
    }
  };

  const sidebarStyle = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={sidebarStyle as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar />
        <div className="flex flex-col flex-1 overflow-hidden">
          <header className="flex items-center justify-between gap-4 p-4 border-b bg-background">
            <div className="flex items-center gap-4">
              <SidebarTrigger />
              <h1 className="font-semibold">{t("history.title")}</h1>
            </div>
            <div className="flex items-center gap-2">
              <LanguageSelector />
              <ThemeToggle />
            </div>
          </header>
          <main className="flex-1 overflow-auto p-6">
            <div className="max-w-6xl mx-auto">
              <Card>
                <CardHeader>
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <CardTitle>{t("history.title")}</CardTitle>
                    <div className="relative w-full sm:w-64">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder={t("common.search")}
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10"
                        data-testid="input-history-search"
                      />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="space-y-4">
                      {[1, 2, 3, 4, 5].map((i) => (
                        <div key={i} className="flex items-center gap-4">
                          <Skeleton className="h-10 w-10 rounded" />
                          <div className="flex-1">
                            <Skeleton className="h-4 w-48 mb-2" />
                            <Skeleton className="h-3 w-32" />
                          </div>
                          <Skeleton className="h-8 w-20" />
                        </div>
                      ))}
                    </div>
                  ) : filteredConversions.length === 0 ? (
                    <div className="text-center py-16 text-muted-foreground">
                      <History className="h-16 w-16 mx-auto mb-4 opacity-50" />
                      <p className="text-lg font-medium mb-2">{t("history.noHistory")}</p>
                      <Button asChild>
                        <Link href="/">
                          <Upload className="mr-2 h-4 w-4" />
                          {t("dashboard.startConverting")}
                        </Link>
                      </Button>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>{t("history.fileName")}</TableHead>
                            <TableHead className="hidden sm:table-cell">{t("history.originalFormat")}</TableHead>
                            <TableHead className="hidden sm:table-cell">{t("history.targetFormat")}</TableHead>
                            <TableHead className="hidden md:table-cell">{t("history.date")}</TableHead>
                            <TableHead>{t("history.status")}</TableHead>
                            <TableHead className="text-right">{t("history.actions")}</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredConversions.map((conversion) => (
                            <TableRow key={conversion.id} data-testid={`row-conversion-${conversion.id}`}>
                              <TableCell>
                                <div className="flex items-center gap-3">
                                  <div className="w-8 h-8 rounded bg-primary/10 flex items-center justify-center flex-shrink-0">
                                    <FileText className="h-4 w-4 text-primary" />
                                  </div>
                                  <div className="min-w-0">
                                    <p className="font-medium truncate max-w-[200px]">
                                      {conversion.originalFileName}
                                    </p>
                                    <p className="text-xs text-muted-foreground sm:hidden">
                                      {conversion.originalFormat.toUpperCase()} → {conversion.targetFormat.toUpperCase()}
                                    </p>
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell className="hidden sm:table-cell">
                                <Badge variant="outline" className="uppercase">
                                  {conversion.originalFormat}
                                </Badge>
                              </TableCell>
                              <TableCell className="hidden sm:table-cell">
                                <Badge variant="secondary" className="uppercase">
                                  {conversion.targetFormat}
                                </Badge>
                              </TableCell>
                              <TableCell className="hidden md:table-cell text-muted-foreground">
                                {formatDate(conversion.createdAt!)}
                              </TableCell>
                              <TableCell>{getStatusBadge(conversion.status)}</TableCell>
                              <TableCell>
                                <div className="flex items-center justify-end gap-2">
                                  {conversion.status === "completed" && conversion.downloadUrl && (
                                    <Button
                                      size="icon"
                                      variant="ghost"
                                      asChild
                                      data-testid={`button-download-${conversion.id}`}
                                    >
                                      <a href={conversion.downloadUrl} download>
                                        <Download className="h-4 w-4" />
                                      </a>
                                    </Button>
                                  )}
                                  <AlertDialog>
                                    <AlertDialogTrigger asChild>
                                      <Button
                                        size="icon"
                                        variant="ghost"
                                        className="text-destructive"
                                        data-testid={`button-delete-${conversion.id}`}
                                      >
                                        <Trash2 className="h-4 w-4" />
                                      </Button>
                                    </AlertDialogTrigger>
                                    <AlertDialogContent>
                                      <AlertDialogHeader>
                                        <AlertDialogTitle>{t("common.confirm")}</AlertDialogTitle>
                                        <AlertDialogDescription>
                                          Are you sure you want to delete this conversion? This action cannot be undone.
                                        </AlertDialogDescription>
                                      </AlertDialogHeader>
                                      <AlertDialogFooter>
                                        <AlertDialogCancel>{t("common.cancel")}</AlertDialogCancel>
                                        <AlertDialogAction
                                          onClick={() => deleteMutation.mutate(conversion.id)}
                                          className="bg-destructive text-destructive-foreground"
                                        >
                                          {t("common.delete")}
                                        </AlertDialogAction>
                                      </AlertDialogFooter>
                                    </AlertDialogContent>
                                  </AlertDialog>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
