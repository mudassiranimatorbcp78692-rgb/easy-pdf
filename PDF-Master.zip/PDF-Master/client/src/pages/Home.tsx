import { useState, useCallback } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation } from "@tanstack/react-query";
import { 
  FileText, 
  History, 
  Settings, 
  LogOut, 
  Upload,
  Clock,
  HardDrive,
  TrendingUp,
  Download,
  ArrowRight,
  Menu
} from "lucide-react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { ThemeToggle } from "@/components/ThemeToggle";
import { LanguageSelector } from "@/components/LanguageSelector";
import { FileUploader } from "@/components/FileUploader";
import { FormatSelector } from "@/components/FormatSelector";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Conversion } from "@shared/schema";

function AppSidebar() {
  const { t } = useTranslation();
  const [location] = useLocation();
  const { user } = useAuth();

  const menuItems = [
    { icon: Upload, label: t("nav.convert"), path: "/" },
    { icon: History, label: t("nav.history"), path: "/history" },
    { icon: Settings, label: t("nav.settings"), path: "/settings" },
  ];

  return (
    <Sidebar>
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <FileText className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="font-semibold text-lg">Easy PDF</span>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>{t("nav.home")}</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.path}>
                  <SidebarMenuButton
                    asChild
                    isActive={location === item.path}
                  >
                    <Link href={item.path} data-testid={`link-nav-${item.path.slice(1) || 'home'}`}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.label}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="p-4">
        <div className="flex items-center gap-3 mb-4">
          <Avatar className="h-9 w-9">
            <AvatarImage src={user?.profileImageUrl || ""} className="object-cover" />
            <AvatarFallback>
              {user?.firstName?.[0] || user?.email?.[0] || "U"}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate" data-testid="text-user-name">
              {user?.firstName ? `${user.firstName} ${user.lastName || ""}`.trim() : user?.email}
            </p>
            <p className="text-xs text-muted-foreground truncate" data-testid="text-user-email">
              {user?.email}
            </p>
          </div>
        </div>
        <Button variant="outline" className="w-full" asChild data-testid="button-logout">
          <a href="/api/logout">
            <LogOut className="h-4 w-4 mr-2" />
            {t("nav.logout")}
          </a>
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}

function DashboardStats() {
  const { t } = useTranslation();
  const { data: conversions, isLoading } = useQuery<Conversion[]>({
    queryKey: ["/api/conversions"],
  });

  const stats = [
    {
      title: t("dashboard.totalConversions"),
      value: conversions?.length || 0,
      icon: <TrendingUp className="h-4 w-4" />,
    },
    {
      title: t("dashboard.recentConversions"),
      value: conversions?.filter(c => {
        const date = new Date(c.createdAt!);
        const now = new Date();
        return now.getTime() - date.getTime() < 24 * 60 * 60 * 1000;
      }).length || 0,
      icon: <Clock className="h-4 w-4" />,
    },
    {
      title: t("dashboard.storageUsed"),
      value: conversions?.reduce((acc, c) => acc + (c.originalFileSize || 0), 0) || 0,
      icon: <HardDrive className="h-4 w-4" />,
      format: "size",
    },
  ];

  const formatValue = (value: number, format?: string) => {
    if (format === "size") {
      if (value === 0) return "0 MB";
      const mb = value / (1024 * 1024);
      return `${mb.toFixed(2)} MB`;
    }
    return value.toString();
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
      {stats.map((stat, index) => (
        <Card key={index}>
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {stat.title}
            </CardTitle>
            <div className="text-muted-foreground">{stat.icon}</div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <div className="text-2xl font-bold" data-testid={`text-stat-${index}`}>
                {formatValue(stat.value, stat.format)}
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function ConverterPanel() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedFormat, setSelectedFormat] = useState<{ from: string; to: string; label: string } | null>(null);
  const [conversionStatus, setConversionStatus] = useState<"idle" | "uploading" | "converting" | "completed" | "error">("idle");
  const [conversionProgress, setConversionProgress] = useState(0);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);

  const getInputFormat = () => {
    if (!selectedFile) return null;
    const ext = selectedFile.name.split(".").pop()?.toLowerCase();
    return ext || null;
  };

  const convertMutation = useMutation({
    mutationFn: async () => {
      if (!selectedFile || !selectedFormat) throw new Error("No file or format selected");

      const formData = new FormData();
      formData.append("file", selectedFile);
      formData.append("targetFormat", selectedFormat.to);

      setConversionStatus("uploading");
      setConversionProgress(20);

      const response = await fetch("/api/convert", {
        method: "POST",
        body: formData,
        credentials: "include",
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Conversion failed");
      }

      setConversionStatus("converting");
      setConversionProgress(60);

      const result = await response.json();
      
      setConversionProgress(100);
      setConversionStatus("completed");
      
      return result;
    },
    onSuccess: (data) => {
      setDownloadUrl(data.downloadUrl);
      toast({
        title: t("common.success"),
        description: t("converter.success"),
      });
      queryClient.invalidateQueries({ queryKey: ["/api/conversions"] });
    },
    onError: (error: Error) => {
      setConversionStatus("error");
      toast({
        title: t("common.error"),
        description: error.message || t("converter.error"),
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = useCallback((file: File) => {
    setSelectedFile(file);
    setSelectedFormat(null);
    setConversionStatus("idle");
    setConversionProgress(0);
    setDownloadUrl(null);
  }, []);

  const handleClearFile = useCallback(() => {
    setSelectedFile(null);
    setSelectedFormat(null);
    setConversionStatus("idle");
    setConversionProgress(0);
    setDownloadUrl(null);
  }, []);

  const handleConvert = () => {
    if (selectedFile && selectedFormat) {
      convertMutation.mutate();
    }
  };

  const handleConvertAnother = () => {
    handleClearFile();
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">{t("converter.title")}</h2>
        <p className="text-muted-foreground">{t("converter.supportedFormats")}</p>
      </div>

      <Card>
        <CardContent className="pt-6">
          <FileUploader
            onFileSelect={handleFileSelect}
            selectedFile={selectedFile}
            onClear={handleClearFile}
            isConverting={convertMutation.isPending}
            conversionProgress={conversionProgress}
            conversionStatus={conversionStatus}
            disabled={conversionStatus === "completed"}
          />
        </CardContent>
      </Card>

      {selectedFile && conversionStatus !== "completed" && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">{t("converter.selectFormat")}</CardTitle>
          </CardHeader>
          <CardContent>
            <FormatSelector
              inputFormat={getInputFormat()}
              selectedFormat={selectedFormat?.to || null}
              onFormatSelect={setSelectedFormat}
            />
          </CardContent>
        </Card>
      )}

      {selectedFile && selectedFormat && conversionStatus === "idle" && (
        <Button 
          size="lg" 
          className="w-full" 
          onClick={handleConvert}
          disabled={convertMutation.isPending}
          data-testid="button-convert"
        >
          {t("converter.convert")}
          <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      )}

      {conversionStatus === "completed" && downloadUrl && (
        <div className="space-y-4">
          <Card className="border-green-500/50 bg-green-500/5">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="w-16 h-16 rounded-full bg-green-500/10 flex items-center justify-center mx-auto mb-4">
                  <Download className="h-8 w-8 text-green-500" />
                </div>
                <h3 className="font-semibold text-lg mb-2">{t("converter.downloadReady")}</h3>
                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <Button asChild data-testid="button-download">
                    <a href={downloadUrl} download>
                      <Download className="mr-2 h-4 w-4" />
                      {t("converter.download")}
                    </a>
                  </Button>
                  <Button variant="outline" onClick={handleConvertAnother} data-testid="button-convert-another">
                    {t("converter.convertAnother")}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}

function RecentConversions() {
  const { t } = useTranslation();
  const { data: conversions, isLoading } = useQuery<Conversion[]>({
    queryKey: ["/api/conversions"],
  });

  const recentConversions = conversions?.slice(0, 5) || [];

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString(undefined, {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge variant="default" className="bg-green-500">{t("history.completed")}</Badge>;
      case "processing":
        return <Badge variant="secondary">{t("history.processing")}</Badge>;
      case "failed":
        return <Badge variant="destructive">{t("history.failed")}</Badge>;
      default:
        return <Badge variant="outline">{t("history.pending")}</Badge>;
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-2">
          <CardTitle>{t("dashboard.recentConversions")}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center gap-4">
                <Skeleton className="h-10 w-10 rounded" />
                <div className="flex-1">
                  <Skeleton className="h-4 w-32 mb-2" />
                  <Skeleton className="h-3 w-24" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2">
        <CardTitle>{t("dashboard.recentConversions")}</CardTitle>
        <Button variant="ghost" size="sm" asChild>
          <Link href="/history">{t("dashboard.viewAll")}</Link>
        </Button>
      </CardHeader>
      <CardContent>
        {recentConversions.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>{t("dashboard.noConversions")}</p>
            <p className="text-sm">{t("dashboard.startConverting")}</p>
          </div>
        ) : (
          <div className="space-y-4">
            {recentConversions.map((conversion) => (
              <div key={conversion.id} className="flex items-center gap-4 p-3 rounded-lg bg-muted/50">
                <div className="w-10 h-10 rounded bg-primary/10 flex items-center justify-center">
                  <FileText className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate text-sm">{conversion.originalFileName}</p>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span className="uppercase">{conversion.originalFormat}</span>
                    <ArrowRight className="h-3 w-3" />
                    <span className="uppercase">{conversion.targetFormat}</span>
                    <span className="hidden sm:inline">•</span>
                    <span className="hidden sm:inline">{formatDate(conversion.createdAt!)}</span>
                  </div>
                </div>
                {getStatusBadge(conversion.status)}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function Home() {
  const { t } = useTranslation();
  const { user } = useAuth();

  const sidebarStyle = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={sidebarStyle as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar />
        <div className="flex flex-col flex-1 overflow-hidden">
          <header className="flex items-center justify-between gap-4 p-4 border-b bg-background">
            <div className="flex items-center gap-4">
              <SidebarTrigger data-testid="button-sidebar-toggle" />
              <div>
                <h1 className="font-semibold">{t("dashboard.welcome")}, {user?.firstName || "User"}!</h1>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <LanguageSelector />
              <ThemeToggle />
            </div>
          </header>
          <main className="flex-1 overflow-auto p-6">
            <div className="max-w-6xl mx-auto">
              <DashboardStats />
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <ConverterPanel />
                </div>
                <div>
                  <RecentConversions />
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
