import { useTranslation } from "react-i18next";
import { Link } from "wouter";
import {
  Zap,
  Shield,
  Gift,
  Layers,
  FileText,
  Table,
  Image,
  BookOpen,
  Presentation,
  Database,
  Upload,
  Settings,
  Download,
  ArrowRight,
  CheckCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ThemeToggle } from "@/components/ThemeToggle";
import { LanguageSelector } from "@/components/LanguageSelector";

export default function Landing() {
  const { t } = useTranslation();

  const features = [
    {
      icon: <Zap className="h-6 w-6" />,
      title: t("landing.features.fast"),
      description: t("landing.features.fastDesc"),
    },
    {
      icon: <Shield className="h-6 w-6" />,
      title: t("landing.features.secure"),
      description: t("landing.features.secureDesc"),
    },
    {
      icon: <Gift className="h-6 w-6" />,
      title: t("landing.features.free"),
      description: t("landing.features.freeDesc"),
    },
    {
      icon: <Layers className="h-6 w-6" />,
      title: t("landing.features.formats"),
      description: t("landing.features.formatsDesc"),
    },
  ];

  const categories = [
    {
      icon: <FileText className="h-8 w-8" />,
      title: t("landing.categories.documents"),
      description: t("landing.categories.documentsDesc"),
      color: "text-blue-500",
      bg: "bg-blue-500/10",
    },
    {
      icon: <Table className="h-8 w-8" />,
      title: t("landing.categories.spreadsheets"),
      description: t("landing.categories.spreadsheetsDesc"),
      color: "text-green-500",
      bg: "bg-green-500/10",
    },
    {
      icon: <Image className="h-8 w-8" />,
      title: t("landing.categories.images"),
      description: t("landing.categories.imagesDesc"),
      color: "text-purple-500",
      bg: "bg-purple-500/10",
    },
    {
      icon: <BookOpen className="h-8 w-8" />,
      title: t("landing.categories.ebooks"),
      description: t("landing.categories.ebooksDesc"),
      color: "text-orange-500",
      bg: "bg-orange-500/10",
    },
    {
      icon: <Presentation className="h-8 w-8" />,
      title: t("landing.categories.presentations"),
      description: t("landing.categories.presentationsDesc"),
      color: "text-red-500",
      bg: "bg-red-500/10",
    },
    {
      icon: <Database className="h-8 w-8" />,
      title: t("landing.categories.data"),
      description: t("landing.categories.dataDesc"),
      color: "text-cyan-500",
      bg: "bg-cyan-500/10",
    },
  ];

  const steps = [
    {
      icon: <Upload className="h-8 w-8" />,
      title: t("landing.howItWorks.step1"),
      description: t("landing.howItWorks.step1Desc"),
    },
    {
      icon: <Settings className="h-8 w-8" />,
      title: t("landing.howItWorks.step2"),
      description: t("landing.howItWorks.step2Desc"),
    },
    {
      icon: <Download className="h-8 w-8" />,
      title: t("landing.howItWorks.step3"),
      description: t("landing.howItWorks.step3Desc"),
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <FileText className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="font-semibold text-lg">Easy PDF</span>
          </div>

          <div className="flex items-center gap-2">
            <LanguageSelector />
            <ThemeToggle />
            <Button asChild data-testid="button-login">
              <a href="/api/login">{t("nav.login")}</a>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-primary/10" />
        <div className="container mx-auto px-4 relative">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text" data-testid="text-hero-title">
              {t("landing.title")}
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto" data-testid="text-hero-subtitle">
              {t("landing.subtitle")}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild className="text-base" data-testid="button-get-started">
                <a href="/api/login">
                  {t("landing.cta")}
                  <ArrowRight className="ml-2 h-5 w-5" />
                </a>
              </Button>
            </div>
            <div className="mt-8 flex items-center justify-center gap-2 text-sm text-muted-foreground">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>{t("landing.trustedBy")}</span>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="border-0 shadow-none bg-transparent">
                <CardContent className="pt-6">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary mb-4">
                    {feature.icon}
                  </div>
                  <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground text-sm">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Format Categories Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">{t("landing.features.formats")}</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              {t("landing.features.formatsDesc")}
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category, index) => (
              <Card key={index} className="hover-elevate transition-all duration-300">
                <CardContent className="pt-6">
                  <div className={`w-14 h-14 rounded-lg ${category.bg} flex items-center justify-center ${category.color} mb-4`}>
                    {category.icon}
                  </div>
                  <h3 className="font-semibold text-lg mb-2">{category.title}</h3>
                  <p className="text-muted-foreground text-sm">{category.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">{t("landing.howItWorks.title")}</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {steps.map((step, index) => (
              <div key={index} className="text-center relative">
                {index < steps.length - 1 && (
                  <div className="hidden md:block absolute top-8 left-[60%] w-[80%] h-0.5 bg-border" />
                )}
                <div className="relative">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary mx-auto mb-4">
                    {step.icon}
                  </div>
                  <div className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-primary text-primary-foreground text-sm font-bold flex items-center justify-center">
                    {index + 1}
                  </div>
                </div>
                <h3 className="font-semibold text-lg mb-2">{step.title}</h3>
                <p className="text-muted-foreground text-sm">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center bg-gradient-to-r from-primary/10 via-primary/5 to-primary/10 rounded-2xl p-12">
            <h2 className="text-3xl font-bold mb-4">{t("landing.cta")}</h2>
            <p className="text-muted-foreground mb-8">
              {t("landing.subtitle")}
            </p>
            <Button size="lg" asChild data-testid="button-cta-bottom">
              <a href="/api/login">
                {t("nav.getStarted")}
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-primary rounded flex items-center justify-center">
                <FileText className="h-4 w-4 text-primary-foreground" />
              </div>
              <span className="font-medium">Easy PDF</span>
            </div>
            <div className="flex items-center gap-6 text-sm text-muted-foreground">
              <span>&copy; 2024 Easy PDF. {t("footer.copyright")}</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
