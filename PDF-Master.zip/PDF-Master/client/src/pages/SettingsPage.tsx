import { useTranslation } from "react-i18next";
import { Link, useLocation } from "wouter";
import {
  FileText,
  History,
  Settings,
  LogOut,
  Upload,
  Globe,
  Moon,
  Sun,
  Monitor,
  Check,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { ThemeToggle } from "@/components/ThemeToggle";
import { LanguageSelector } from "@/components/LanguageSelector";
import { useTheme } from "@/components/ThemeProvider";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { languages, isRTL } from "@/lib/i18n";
import { cn } from "@/lib/utils";

function AppSidebar() {
  const { t } = useTranslation();
  const [location] = useLocation();
  const { user } = useAuth();

  const menuItems = [
    { icon: Upload, label: t("nav.convert"), path: "/" },
    { icon: History, label: t("nav.history"), path: "/history" },
    { icon: Settings, label: t("nav.settings"), path: "/settings" },
  ];

  return (
    <Sidebar>
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <FileText className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="font-semibold text-lg">Easy PDF</span>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>{t("nav.home")}</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.path}>
                  <SidebarMenuButton
                    asChild
                    isActive={location === item.path}
                  >
                    <Link href={item.path}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.label}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="p-4">
        <div className="flex items-center gap-3 mb-4">
          <Avatar className="h-9 w-9">
            <AvatarImage src={user?.profileImageUrl || ""} className="object-cover" />
            <AvatarFallback>
              {user?.firstName?.[0] || user?.email?.[0] || "U"}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">
              {user?.firstName ? `${user.firstName} ${user.lastName || ""}`.trim() : user?.email}
            </p>
            <p className="text-xs text-muted-foreground truncate">
              {user?.email}
            </p>
          </div>
        </div>
        <Button variant="outline" className="w-full" asChild>
          <a href="/api/logout">
            <LogOut className="h-4 w-4 mr-2" />
            {t("nav.logout")}
          </a>
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}

export default function SettingsPage() {
  const { t, i18n } = useTranslation();
  const { toast } = useToast();
  const { theme, setTheme } = useTheme();

  const handleLanguageChange = (langCode: string) => {
    i18n.changeLanguage(langCode);
    document.documentElement.dir = isRTL(langCode) ? "rtl" : "ltr";
    document.documentElement.lang = langCode;
    toast({
      title: t("common.success"),
      description: t("settings.saved"),
    });
  };

  const handleThemeChange = (newTheme: "light" | "dark" | "system") => {
    setTheme(newTheme);
    toast({
      title: t("common.success"),
      description: t("settings.saved"),
    });
  };

  const sidebarStyle = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={sidebarStyle as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar />
        <div className="flex flex-col flex-1 overflow-hidden">
          <header className="flex items-center justify-between gap-4 p-4 border-b bg-background">
            <div className="flex items-center gap-4">
              <SidebarTrigger />
              <h1 className="font-semibold">{t("settings.title")}</h1>
            </div>
            <div className="flex items-center gap-2">
              <LanguageSelector />
              <ThemeToggle />
            </div>
          </header>
          <main className="flex-1 overflow-auto p-6">
            <div className="max-w-2xl mx-auto space-y-6">
              {/* Language Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Globe className="h-5 w-5" />
                    {t("settings.language")}
                  </CardTitle>
                  <CardDescription>
                    Select your preferred language for the interface
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                    {languages.map((lang) => (
                      <button
                        key={lang.code}
                        onClick={() => handleLanguageChange(lang.code)}
                        className={cn(
                          "flex items-center justify-between gap-2 p-3 rounded-lg border text-left transition-all hover-elevate",
                          i18n.language === lang.code
                            ? "border-primary bg-primary/5"
                            : "border-transparent bg-muted/50"
                        )}
                        data-testid={`button-lang-${lang.code}`}
                      >
                        <div className="min-w-0">
                          <p className={cn(
                            "font-medium text-sm truncate",
                            lang.rtl && "font-arabic"
                          )}>
                            {lang.nativeName}
                          </p>
                          <p className="text-xs text-muted-foreground truncate">
                            {lang.name}
                          </p>
                        </div>
                        {i18n.language === lang.code && (
                          <Check className="h-4 w-4 text-primary flex-shrink-0" />
                        )}
                      </button>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Theme Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sun className="h-5 w-5" />
                    {t("settings.theme")}
                  </CardTitle>
                  <CardDescription>
                    Choose your preferred color theme
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <RadioGroup
                    value={theme}
                    onValueChange={(value) => handleThemeChange(value as "light" | "dark" | "system")}
                    className="grid grid-cols-3 gap-4"
                  >
                    <div>
                      <RadioGroupItem
                        value="light"
                        id="theme-light"
                        className="peer sr-only"
                      />
                      <Label
                        htmlFor="theme-light"
                        className="flex flex-col items-center justify-between rounded-lg border-2 border-muted bg-popover p-4 cursor-pointer hover-elevate peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                        data-testid="button-theme-light"
                      >
                        <Sun className="mb-3 h-6 w-6" />
                        <span className="text-sm font-medium">
                          {t("settings.themeLight")}
                        </span>
                      </Label>
                    </div>
                    <div>
                      <RadioGroupItem
                        value="dark"
                        id="theme-dark"
                        className="peer sr-only"
                      />
                      <Label
                        htmlFor="theme-dark"
                        className="flex flex-col items-center justify-between rounded-lg border-2 border-muted bg-popover p-4 cursor-pointer hover-elevate peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                        data-testid="button-theme-dark"
                      >
                        <Moon className="mb-3 h-6 w-6" />
                        <span className="text-sm font-medium">
                          {t("settings.themeDark")}
                        </span>
                      </Label>
                    </div>
                    <div>
                      <RadioGroupItem
                        value="system"
                        id="theme-system"
                        className="peer sr-only"
                      />
                      <Label
                        htmlFor="theme-system"
                        className="flex flex-col items-center justify-between rounded-lg border-2 border-muted bg-popover p-4 cursor-pointer hover-elevate peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                        data-testid="button-theme-system"
                      >
                        <Monitor className="mb-3 h-6 w-6" />
                        <span className="text-sm font-medium">
                          {t("settings.themeSystem")}
                        </span>
                      </Label>
                    </div>
                  </RadioGroup>
                </CardContent>
              </Card>
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
