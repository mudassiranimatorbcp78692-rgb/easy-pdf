# Easy PDF - Design Guidelines

## Design Approach

**Reference-Based Approach**: Drawing inspiration from modern SaaS platforms like Notion (clean layouts), Linear (precise typography), and Dropbox (file handling UX). The design emphasizes trust, efficiency, and professional-grade quality suitable for a premium conversion service.

## Core Design Principles

1. **Trust & Professionalism**: Clean, minimal design that conveys security and reliability
2. **Efficient Workflows**: Streamlined conversion process with clear visual feedback
3. **Scalable Information Architecture**: Organize 50+ format options without overwhelming users
4. **Multilingual Excellence**: RTL support for Arabic/Urdu, consistent spacing across languages

---

## Typography

**Primary Font**: Inter (via Google Fonts)
- Headings: 600-700 weight
- Body: 400-500 weight
- Small text/captions: 400 weight

**Hierarchy**:
- Hero/Page Titles: text-4xl to text-5xl, font-semibold
- Section Headers: text-2xl to text-3xl, font-semibold
- Card Titles: text-lg to text-xl, font-medium
- Body Text: text-base, font-normal
- Small/Meta Text: text-sm, font-normal

---

## Layout System

**Spacing Primitives**: Use Tailwind units of **4, 6, 8, 12, 16, 24** consistently
- Component padding: p-6 to p-8
- Section spacing: py-16 to py-24
- Card gaps: gap-6 to gap-8
- Element margins: mb-4, mt-8, etc.

**Container Widths**:
- Marketing pages: max-w-7xl
- Dashboard: max-w-screen-2xl
- Content sections: max-w-6xl
- Forms/Upload areas: max-w-3xl

---

## Page-Specific Designs

### Landing Page

**Hero Section** (h-screen or min-h-[600px]):
- Large, clean hero image showcasing PDF conversion concept (abstract documents, clean graphics, or workflow visualization)
- Centered headline and subheadline with clear value proposition
- Primary CTA button with blurred background overlay
- Trust indicators below CTA: "Trusted by 10,000+ users • 50M+ files converted"

**Format Showcase Section**:
- 3-column grid (lg:grid-cols-3) displaying conversion categories
- Icon-based cards for: Documents, Spreadsheets, Images, E-books, Vector Graphics, Audio
- Each card: large icon, category title, format count, hover lift effect

**How It Works** (3-step process):
- Horizontal 3-column layout with numbered steps
- Icons + titles + descriptions
- Visual connectors between steps (arrow graphics or dotted lines)

**Features Grid**:
- 2-column layout showcasing: Multilingual Support, Secure Processing, Cloud Storage, Download History
- Icon + headline + description format
- Generous spacing between features (gap-8)

**Pricing/CTA Section**:
- Centered layout with background accent
- Large CTA button with secondary link below
- Trust badges and security indicators

### Dashboard Layout

**Sidebar Navigation** (w-64, fixed):
- Logo at top
- Navigation items with icons: Dashboard, New Conversion, History, Settings
- Language selector at bottom
- User profile section with avatar

**Main Content Area** (ml-64):
- Top bar: Page title, user actions, theme toggle
- Content cards with shadow-sm, rounded-lg borders
- Stats overview: 4-column grid showing total conversions, storage used, recent activity

**Conversion Interface**:
- Large drag-and-drop zone (min-h-[400px]) with dashed border
- File preview area below upload zone
- Format selector: searchable dropdown or category tabs
- Conversion settings in collapsible panel
- Large "Convert" button (w-full or centered)
- Progress indicator: linear progress bar with percentage

**History Page**:
- Table layout with columns: File Name, Format, Date, Size, Status, Actions
- Filter/search bar at top
- Pagination at bottom
- Download/delete action buttons per row

### Authentication Pages

**Login/Signup**:
- Centered card layout (max-w-md, mx-auto)
- Logo and tagline at top
- Social login buttons (Google, GitHub) with icons
- Divider with "or" text
- Email/password form fields
- Clear CTAs and helper links
- Language selector in top-right corner

---

## Component Library

### File Upload Component
- Dashed border (border-2, border-dashed) when empty
- Solid border when file is dragged over
- Large upload icon and instructional text
- File type indicators (PDF, formats accepted)
- Browse button as secondary action

### Conversion Cards
- White/dark background with shadow-sm
- Icon (64px) at top or left
- Format name and description
- Arrow or chevron indicating directionality (PDF ⇄ FORMAT)
- Hover state: slight elevation (shadow-md)

### Progress Indicators
- Linear progress bar with gradient fill
- Percentage text overlay
- Status text below: "Converting... • 45% complete"
- Success/error states with color coding

### Language Selector
- Dropdown with flag icons
- Current language displayed with flag
- Searchable list for 20+ languages
- RTL layout switch for Arabic/Urdu

### Theme Toggle
- Icon-based toggle (sun/moon icons)
- Smooth transition between modes
- Persistent user preference

---

## Navigation & Interactions

**Header** (Marketing):
- Logo (left), nav links (center), Login/Signup + Language selector (right)
- Sticky on scroll with backdrop blur
- Mobile: hamburger menu

**Dashboard Header**:
- Breadcrumb navigation
- Action buttons (New Conversion, etc.)
- User menu dropdown (Profile, Settings, Logout)
- Theme toggle

**Buttons**:
- Primary: Large, rounded-lg, font-medium with icon support
- Secondary: Outlined or ghost style
- On images: backdrop-blur-sm with semi-transparent background
- No custom hover states - use default

---

## Images

**Hero Image**: Large, high-quality abstract visualization of document conversion workflow - clean graphics showing PDFs transforming into multiple formats, modern gradient overlays, professional and trustworthy aesthetic (1920x1080 minimum)

**Feature Icons**: Use Font Awesome or Heroicons for category/feature icons

**Format Icons**: Document, spreadsheet, image, ebook, vector icons to represent each conversion category

---

## Animations

**Minimal Usage**:
- Smooth page transitions (fade-in on load)
- Upload zone pulse effect when dragging files
- Progress bar animation during conversion
- Success checkmark animation on completion
- Avoid excessive scroll animations or parallax effects

---

## Accessibility & RTL

- Full RTL support with dir="rtl" for Arabic/Urdu
- Mirrored layouts (sidebar switches to right, text alignment flips)
- Keyboard navigation for all interactive elements
- ARIA labels for file uploads and conversion status
- High contrast mode compatibility
- Focus states on all interactive elements