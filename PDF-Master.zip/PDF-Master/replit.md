# Easy PDF - File Conversion Application

## Overview

Easy PDF is a web-based file conversion platform that allows users to convert PDF files and other document formats to 50+ different formats. The application focuses on providing a fast, secure, and user-friendly conversion experience with support for multiple languages including RTL (Right-to-Left) languages like Arabic and Urdu. Built as a full-stack TypeScript application, it uses modern web technologies to deliver a responsive, professional interface for file conversion tasks.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- **React 18** with TypeScript for the UI layer, chosen for its component-based architecture and strong ecosystem
- **Vite** as the build tool and development server, selected for fast HMR (Hot Module Replacement) and optimized production builds
- **Wouter** for lightweight client-side routing instead of React Router, reducing bundle size while maintaining essential routing capabilities

**UI Component Library**
- **shadcn/ui** components built on **Radix UI primitives**, providing accessible, unstyled components that can be customized
- **Tailwind CSS** for utility-first styling with custom design tokens defined in the configuration
- **CVA (Class Variance Authority)** for managing component variants systematically
- Design system follows guidelines inspired by Notion, Linear, and Dropbox with emphasis on clean layouts and professional aesthetics

**State Management**
- **TanStack Query (React Query)** for server state management, handling data fetching, caching, and synchronization
- Local component state using React hooks for UI-specific state
- Custom hooks pattern for reusable logic (e.g., `useAuth`, `useIsMobile`)

**Internationalization**
- **i18next** with react-i18next for multi-language support
- Built-in RTL (Right-to-Left) support for Arabic, Urdu, and other RTL languages
- Language detection and persistence in browser storage

**Form Handling**
- **React Hook Form** with **@hookform/resolvers** for form state management
- **Zod** for schema validation and type-safe form inputs

### Backend Architecture

**Server Framework**
- **Express.js** running on Node.js for the HTTP server
- TypeScript throughout the backend for type safety
- Custom middleware for logging, error handling, and request processing

**Authentication & Sessions**
- **Replit Auth** integration using OpenID Connect (OIDC) for user authentication
- **Passport.js** with OpenID Client strategy for authentication flow
- **express-session** with PostgreSQL session store (`connect-pg-simple`) for persistent sessions
- Session-based authentication with secure, HTTP-only cookies (7-day TTL)

**File Processing**
- **Multer** for handling multipart/form-data file uploads
- File size limit: 50MB per upload
- Local filesystem storage in `uploads/` and `outputs/` directories
- **pdf-parse** library for PDF text extraction and analysis
- Command-line utilities (via `child_process.exec`) for file format conversions
- Support for conversions between 50+ formats across categories: documents, spreadsheets, images, e-books, presentations, and data files

**API Design**
- RESTful API endpoints under `/api` prefix
- Authentication middleware (`isAuthenticated`) protecting user-specific routes
- File upload endpoint with format conversion logic
- Conversion history tracking and management endpoints

### Data Storage Solutions

**Database**
- **PostgreSQL** as the primary relational database
- **Drizzle ORM** for type-safe database queries and schema management
- Connection pooling via `pg` (node-postgres) for efficient database connections

**Database Schema**
The database uses three core tables:

1. **sessions** - Required for Replit Auth, stores user session data with expiration
2. **users** - Stores user profiles with email, name, profile image, and language preferences
3. **conversions** - Tracks conversion history with original/target formats, file sizes, status, and error messages

Schema is defined in TypeScript using Drizzle ORM's schema builder, with migrations managed through `drizzle-kit`.

**File Storage**
- Local filesystem for temporary file storage during conversions
- Uploaded files stored in `uploads/` directory
- Converted files stored in `outputs/` directory
- Files are named with timestamps and random suffixes to prevent collisions

### External Dependencies

**Core Runtime Dependencies**
- **Node.js** runtime environment
- **PostgreSQL** database server (required via `DATABASE_URL` environment variable)

**Authentication Service**
- **Replit Auth OIDC Provider** - OAuth2/OpenID Connect authentication service
- Configured via `ISSUER_URL` (defaults to https://replit.com/oidc) and `REPL_ID`
- Requires `SESSION_SECRET` environment variable for session encryption

**Third-Party Libraries & Services**

*File Processing*
- **pdf-parse** - PDF parsing and text extraction
- **xlsx** - Excel file processing
- System-level conversion tools (invoked via shell commands) for format conversions

*Development Tools*
- **Vite plugins** from Replit (`@replit/vite-plugin-runtime-error-modal`, `@replit/vite-plugin-cartographer`, `@replit/vite-plugin-dev-banner`) for enhanced development experience in Replit environment
- **TypeScript** for type checking across the entire codebase
- **ESBuild** for server-side bundling in production builds

*UI Component Dependencies*
- **Radix UI** component primitives (accordion, alert-dialog, avatar, checkbox, dialog, dropdown-menu, popover, progress, radio-group, scroll-area, select, separator, slider, switch, tabs, toast, tooltip)
- **Lucide React** for iconography
- **react-dropzone** for drag-and-drop file uploads
- **date-fns** for date formatting and manipulation
- **cmdk** for command palette/search interfaces

*Utilities*
- **clsx** and **tailwind-merge** for conditional CSS class management
- **nanoid** for generating unique IDs
- **memoizee** for function memoization (used in OIDC config caching)

**Environment Variables Required**
- `DATABASE_URL` - PostgreSQL connection string
- `SESSION_SECRET` - Secret key for session encryption
- `REPL_ID` - Replit application identifier (for auth)
- `ISSUER_URL` - OIDC issuer URL (optional, defaults to Replit's OIDC endpoint)
- `NODE_ENV` - Environment mode (development/production)

**Build & Deployment**
- Production builds bundle allowed server dependencies to reduce cold start times by minimizing file system operations
- Client assets built separately and served from `dist/public`
- Server code bundled to single `dist/index.cjs` file using ESBuild