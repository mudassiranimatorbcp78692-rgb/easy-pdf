import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import multer from "multer";
import path from "path";
import fs from "fs";
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

async function parsePDF(buffer: Buffer): Promise<{ text: string; numpages: number; info: any }> {
  const pdfParse = (await import("pdf-parse")).default;
  return await pdfParse(buffer);
}

const uploadsDir = path.join(process.cwd(), "uploads");
const outputsDir = path.join(process.cwd(), "outputs");

if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}
if (!fs.existsSync(outputsDir)) {
  fs.mkdirSync(outputsDir, { recursive: true });
}

const upload = multer({
  storage: multer.diskStorage({
    destination: uploadsDir,
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
      cb(null, uniqueSuffix + "-" + file.originalname);
    },
  }),
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
  },
});

async function convertFile(
  inputPath: string,
  outputFormat: string,
  originalName: string
): Promise<{ outputPath: string; outputSize: number }> {
  const inputExt = path.extname(inputPath).toLowerCase().slice(1);
  const baseName = path.basename(originalName, path.extname(originalName));
  const outputFileName = `${baseName}-${Date.now()}.${outputFormat}`;
  const outputPath = path.join(outputsDir, outputFileName);

  try {
    if (inputExt === "pdf") {
      switch (outputFormat) {
        case "txt": {
          const dataBuffer = fs.readFileSync(inputPath);
          const data = await parsePDF(dataBuffer);
          fs.writeFileSync(outputPath, data.text);
          break;
        }
        case "png":
        case "jpg":
        case "jpeg": {
          await execAsync(
            `pdftoppm -${outputFormat === "jpg" ? "jpeg" : outputFormat} -r 150 "${inputPath}" "${outputPath.replace(`.${outputFormat}`, "")}"`
          );
          const files = fs.readdirSync(outputsDir).filter(f => f.startsWith(baseName) && f.endsWith(`.${outputFormat}`));
          if (files.length > 0) {
            const firstFile = path.join(outputsDir, files[0]);
            if (firstFile !== outputPath) {
              fs.renameSync(firstFile, outputPath);
            }
          }
          break;
        }
        case "docx":
        case "doc":
        case "odt":
        case "rtf":
        case "html": {
          await execAsync(
            `soffice --headless --convert-to ${outputFormat} --outdir "${outputsDir}" "${inputPath}"`
          );
          const expectedName = path.basename(inputPath, path.extname(inputPath)) + `.${outputFormat}`;
          const expectedPath = path.join(outputsDir, expectedName);
          if (fs.existsSync(expectedPath) && expectedPath !== outputPath) {
            fs.renameSync(expectedPath, outputPath);
          }
          break;
        }
        case "csv":
        case "xlsx":
        case "xls": {
          const dataBuffer = fs.readFileSync(inputPath);
          const data = await parsePDF(dataBuffer);
          const lines = data.text.split("\n").filter(line => line.trim());
          if (outputFormat === "csv") {
            fs.writeFileSync(outputPath, lines.join("\n"));
          } else {
            const csvPath = outputPath.replace(`.${outputFormat}`, ".csv");
            fs.writeFileSync(csvPath, lines.join("\n"));
            await execAsync(
              `soffice --headless --convert-to ${outputFormat} --outdir "${outputsDir}" "${csvPath}"`
            );
            if (fs.existsSync(csvPath)) fs.unlinkSync(csvPath);
          }
          break;
        }
        case "json": {
          const dataBuffer = fs.readFileSync(inputPath);
          const data = await parsePDF(dataBuffer);
          const result = {
            text: data.text,
            pages: data.numpages,
            info: data.info,
          };
          fs.writeFileSync(outputPath, JSON.stringify(result, null, 2));
          break;
        }
        case "xml": {
          const dataBuffer = fs.readFileSync(inputPath);
          const data = await parsePDF(dataBuffer);
          const xml = `<?xml version="1.0" encoding="UTF-8"?>
<document>
  <pages>${data.numpages}</pages>
  <content><![CDATA[${data.text}]]></content>
</document>`;
          fs.writeFileSync(outputPath, xml);
          break;
        }
        case "md": {
          const dataBuffer = fs.readFileSync(inputPath);
          const data = await parsePDF(dataBuffer);
          const paragraphs = data.text.split("\n\n").filter(p => p.trim());
          const markdown = paragraphs.map(p => p.trim()).join("\n\n");
          fs.writeFileSync(outputPath, markdown);
          break;
        }
        case "svg":
        case "tiff":
        case "bmp":
        case "webp":
        case "gif": {
          const pngPath = outputPath.replace(`.${outputFormat}`, ".png");
          await execAsync(`pdftoppm -png -r 150 -singlefile "${inputPath}" "${pngPath.replace(".png", "")}"`);
          await execAsync(`convert "${pngPath}" "${outputPath}"`);
          if (fs.existsSync(pngPath)) fs.unlinkSync(pngPath);
          break;
        }
        case "pptx":
        case "ppt": {
          await execAsync(
            `soffice --headless --convert-to ${outputFormat} --outdir "${outputsDir}" "${inputPath}"`
          );
          break;
        }
        case "epub": {
          const dataBuffer = fs.readFileSync(inputPath);
          const data = await parsePDF(dataBuffer);
          const htmlContent = `<!DOCTYPE html>
<html>
<head><title>Converted Document</title></head>
<body>${data.text.split("\n").map(line => `<p>${line}</p>`).join("\n")}</body>
</html>`;
          const htmlPath = outputPath.replace(".epub", ".html");
          fs.writeFileSync(htmlPath, htmlContent);
          await execAsync(`pandoc "${htmlPath}" -o "${outputPath}" 2>/dev/null || echo "Pandoc not available, creating simple epub"`);
          if (!fs.existsSync(outputPath)) {
            fs.writeFileSync(outputPath, htmlContent);
          }
          if (fs.existsSync(htmlPath)) fs.unlinkSync(htmlPath);
          break;
        }
        default: {
          await execAsync(
            `soffice --headless --convert-to ${outputFormat} --outdir "${outputsDir}" "${inputPath}"`
          );
        }
      }
    } else if (["docx", "doc", "odt", "rtf", "txt", "html"].includes(inputExt)) {
      if (outputFormat === "pdf") {
        await execAsync(
          `soffice --headless --convert-to pdf --outdir "${outputsDir}" "${inputPath}"`
        );
        const expectedName = path.basename(inputPath, path.extname(inputPath)) + ".pdf";
        const expectedPath = path.join(outputsDir, expectedName);
        if (fs.existsSync(expectedPath) && expectedPath !== outputPath) {
          fs.renameSync(expectedPath, outputPath);
        }
      } else {
        await execAsync(
          `soffice --headless --convert-to ${outputFormat} --outdir "${outputsDir}" "${inputPath}"`
        );
      }
    } else if (["xlsx", "xls", "csv", "ods"].includes(inputExt)) {
      await execAsync(
        `soffice --headless --convert-to ${outputFormat} --outdir "${outputsDir}" "${inputPath}"`
      );
    } else if (["png", "jpg", "jpeg", "gif", "bmp", "webp", "tiff"].includes(inputExt)) {
      if (outputFormat === "pdf") {
        await execAsync(`convert "${inputPath}" "${outputPath}"`);
      } else {
        await execAsync(`convert "${inputPath}" "${outputPath}"`);
      }
    } else if (["pptx", "ppt", "odp"].includes(inputExt)) {
      await execAsync(
        `soffice --headless --convert-to ${outputFormat} --outdir "${outputsDir}" "${inputPath}"`
      );
    } else if (inputExt === "epub") {
      if (outputFormat === "pdf") {
        await execAsync(`ebook-convert "${inputPath}" "${outputPath}" 2>/dev/null || soffice --headless --convert-to pdf --outdir "${outputsDir}" "${inputPath}"`);
      }
    } else {
      await execAsync(
        `soffice --headless --convert-to ${outputFormat} --outdir "${outputsDir}" "${inputPath}"`
      );
    }

    if (!fs.existsSync(outputPath)) {
      const possibleFiles = fs.readdirSync(outputsDir).filter(f => 
        f.includes(baseName) && f.endsWith(`.${outputFormat}`)
      );
      if (possibleFiles.length > 0) {
        const foundFile = path.join(outputsDir, possibleFiles[0]);
        fs.renameSync(foundFile, outputPath);
      } else {
        throw new Error(`Conversion failed - output file not created`);
      }
    }

    const stats = fs.statSync(outputPath);
    return { outputPath, outputSize: stats.size };
  } catch (error: any) {
    console.error("Conversion error:", error);
    throw new Error(`Conversion failed: ${error.message}`);
  }
}

export async function registerRoutes(server: Server, app: Express): Promise<void> {
  await setupAuth(app);

  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.get("/api/conversions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const conversions = await storage.getConversions(userId);
      res.json(conversions);
    } catch (error) {
      console.error("Error fetching conversions:", error);
      res.status(500).json({ message: "Failed to fetch conversions" });
    }
  });

  app.post("/api/convert", isAuthenticated, upload.single("file"), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const file = req.file;
      const targetFormat = req.body.targetFormat?.toLowerCase();

      if (!file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      if (!targetFormat) {
        return res.status(400).json({ message: "No target format specified" });
      }

      const originalFormat = path.extname(file.originalname).slice(1).toLowerCase();

      const conversion = await storage.createConversion({
        userId,
        originalFileName: file.originalname,
        originalFormat,
        targetFormat,
        originalFileSize: file.size,
        status: "processing",
      });

      try {
        const { outputPath, outputSize } = await convertFile(
          file.path,
          targetFormat,
          file.originalname
        );

        const downloadUrl = `/api/download/${path.basename(outputPath)}`;

        const updated = await storage.updateConversion(conversion.id, {
          status: "completed",
          convertedFileSize: outputSize,
          downloadUrl,
          completedAt: new Date(),
        });

        if (fs.existsSync(file.path)) {
          fs.unlinkSync(file.path);
        }

        res.json({
          id: conversion.id,
          status: "completed",
          downloadUrl,
          convertedFileSize: outputSize,
        });
      } catch (conversionError: any) {
        await storage.updateConversion(conversion.id, {
          status: "failed",
          errorMessage: conversionError.message,
        });

        if (fs.existsSync(file.path)) {
          fs.unlinkSync(file.path);
        }

        res.status(500).json({
          message: conversionError.message || "Conversion failed",
        });
      }
    } catch (error: any) {
      console.error("Error processing conversion:", error);
      res.status(500).json({ message: error.message || "Failed to process conversion" });
    }
  });

  app.get("/api/download/:filename", isAuthenticated, async (req, res) => {
    try {
      const filename = req.params.filename;
      const filePath = path.join(outputsDir, filename);

      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ message: "File not found" });
      }

      res.download(filePath, filename);
    } catch (error) {
      console.error("Error downloading file:", error);
      res.status(500).json({ message: "Failed to download file" });
    }
  });

  app.delete("/api/conversions/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const conversionId = req.params.id;

      const conversion = await storage.getConversion(conversionId);
      if (!conversion) {
        return res.status(404).json({ message: "Conversion not found" });
      }

      if (conversion.userId !== userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      if (conversion.downloadUrl) {
        const filename = path.basename(conversion.downloadUrl);
        const filePath = path.join(outputsDir, filename);
        if (fs.existsSync(filePath)) {
          fs.unlinkSync(filePath);
        }
      }

      await storage.deleteConversion(conversionId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting conversion:", error);
      res.status(500).json({ message: "Failed to delete conversion" });
    }
  });
}
