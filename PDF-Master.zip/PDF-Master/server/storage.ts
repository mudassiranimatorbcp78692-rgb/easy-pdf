import {
  users,
  conversions,
  type User,
  type UpsertUser,
  type Conversion,
  type InsertConversion,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getConversions(userId: string): Promise<Conversion[]>;
  getConversion(id: string): Promise<Conversion | undefined>;
  createConversion(conversion: InsertConversion): Promise<Conversion>;
  updateConversion(id: string, data: Partial<Conversion>): Promise<Conversion | undefined>;
  deleteConversion(id: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getConversions(userId: string): Promise<Conversion[]> {
    return await db
      .select()
      .from(conversions)
      .where(eq(conversions.userId, userId))
      .orderBy(desc(conversions.createdAt));
  }

  async getConversion(id: string): Promise<Conversion | undefined> {
    const [conversion] = await db.select().from(conversions).where(eq(conversions.id, id));
    return conversion;
  }

  async createConversion(conversion: InsertConversion): Promise<Conversion> {
    const [newConversion] = await db
      .insert(conversions)
      .values(conversion)
      .returning();
    return newConversion;
  }

  async updateConversion(id: string, data: Partial<Conversion>): Promise<Conversion | undefined> {
    const [updated] = await db
      .update(conversions)
      .set(data)
      .where(eq(conversions.id, id))
      .returning();
    return updated;
  }

  async deleteConversion(id: string): Promise<boolean> {
    const result = await db.delete(conversions).where(eq(conversions.id, id)).returning();
    return result.length > 0;
  }
}

export const storage = new DatabaseStorage();
