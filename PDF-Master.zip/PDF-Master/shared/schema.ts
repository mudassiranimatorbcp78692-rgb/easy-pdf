import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  preferredLanguage: varchar("preferred_language").default("en"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Conversion history table
export const conversions = pgTable("conversions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  originalFileName: text("original_file_name").notNull(),
  originalFormat: varchar("original_format").notNull(),
  targetFormat: varchar("target_format").notNull(),
  originalFileSize: integer("original_file_size").notNull(),
  convertedFileSize: integer("converted_file_size"),
  status: varchar("status").notNull().default("pending"), // pending, processing, completed, failed
  errorMessage: text("error_message"),
  downloadUrl: text("download_url"),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

// Supported conversion formats
export const conversionFormats = {
  documents: [
    { from: "pdf", to: "docx", label: "PDF to DOCX" },
    { from: "pdf", to: "doc", label: "PDF to DOC" },
    { from: "pdf", to: "txt", label: "PDF to TXT" },
    { from: "pdf", to: "rtf", label: "PDF to RTF" },
    { from: "pdf", to: "odt", label: "PDF to ODT" },
    { from: "pdf", to: "html", label: "PDF to HTML" },
    { from: "pdf", to: "md", label: "PDF to Markdown" },
    { from: "docx", to: "pdf", label: "DOCX to PDF" },
    { from: "doc", to: "pdf", label: "DOC to PDF" },
    { from: "txt", to: "pdf", label: "TXT to PDF" },
    { from: "rtf", to: "pdf", label: "RTF to PDF" },
    { from: "odt", to: "pdf", label: "ODT to PDF" },
    { from: "html", to: "pdf", label: "HTML to PDF" },
  ],
  spreadsheets: [
    { from: "pdf", to: "xlsx", label: "PDF to XLSX" },
    { from: "pdf", to: "xls", label: "PDF to XLS" },
    { from: "pdf", to: "csv", label: "PDF to CSV" },
    { from: "pdf", to: "ods", label: "PDF to ODS" },
    { from: "xlsx", to: "pdf", label: "XLSX to PDF" },
    { from: "xls", to: "pdf", label: "XLS to PDF" },
    { from: "csv", to: "pdf", label: "CSV to PDF" },
  ],
  images: [
    { from: "pdf", to: "png", label: "PDF to PNG" },
    { from: "pdf", to: "jpg", label: "PDF to JPG" },
    { from: "pdf", to: "jpeg", label: "PDF to JPEG" },
    { from: "pdf", to: "gif", label: "PDF to GIF" },
    { from: "pdf", to: "tiff", label: "PDF to TIFF" },
    { from: "pdf", to: "bmp", label: "PDF to BMP" },
    { from: "pdf", to: "webp", label: "PDF to WEBP" },
    { from: "pdf", to: "svg", label: "PDF to SVG" },
    { from: "png", to: "pdf", label: "PNG to PDF" },
    { from: "jpg", to: "pdf", label: "JPG to PDF" },
    { from: "jpeg", to: "pdf", label: "JPEG to PDF" },
  ],
  ebooks: [
    { from: "pdf", to: "epub", label: "PDF to EPUB" },
    { from: "pdf", to: "mobi", label: "PDF to MOBI" },
    { from: "epub", to: "pdf", label: "EPUB to PDF" },
  ],
  presentations: [
    { from: "pdf", to: "pptx", label: "PDF to PPTX" },
    { from: "pdf", to: "ppt", label: "PDF to PPT" },
    { from: "pptx", to: "pdf", label: "PPTX to PDF" },
    { from: "ppt", to: "pdf", label: "PPT to PDF" },
  ],
  data: [
    { from: "pdf", to: "xml", label: "PDF to XML" },
    { from: "pdf", to: "json", label: "PDF to JSON" },
  ],
};

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

export const insertConversionSchema = createInsertSchema(conversions).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export type InsertConversion = z.infer<typeof insertConversionSchema>;
export type Conversion = typeof conversions.$inferSelect;
